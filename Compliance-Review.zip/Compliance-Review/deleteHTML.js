var reg = new RegExp('<[^>]+>', 'gi');  //过滤所有的html标签，不包括内容

// var reg2 = /<(img|br|hr|input)[^>]*>/gi;  //只匹配img、br、hr、input标签
var reg2 = new RegExp('<(img|br|hr|input)[^>]*>', 'gi');  //只匹配img、br、hr、input标签

// var reg3 = /<(\S*)[^>]*>[^<]*<\/(\1)>/gi;        //分组匹配，过滤所有的html标签，包括内容
var reg3 = new RegExp('<(\\S*)[^>]*>[^<]*<\\/(\\1)>', 'gi');  //分组匹配，过滤所有的html标签，包括内容



/*
* 将所有的标签过滤，不过滤标签内内容
* */
 function filterHtml(str) {
    if (typeof str != 'string') {  //不是字符串
        return str;
    }
    var result = str.replace(reg, '');

    return result;
}

/*
* 讲所有的标签过滤，也过滤标签内的内容
* str 需要过滤的字符串
* isbool  为false则需要单标签过滤，为true则不需要单标签过滤
* */
 function filterHtmlOrContainer(str, isbool) {
    if (typeof str != 'string') {  //不是字符串
        return str;
    }
    var result = str;
    if (!isbool) {  //先把单标签过滤了
        result = result.replace(reg2, '');
    }
    result = result.replace(reg3, '');    //先经过分组匹配，把双标签去除，如果是嵌套标签，则会先将嵌套标签内的双标签过滤掉
    if (reg3.test(result)) { //如果为true，则代表还有标签
        return filterHtmlOrContainer(result, true);
    } else {
        return result;
    }
}
