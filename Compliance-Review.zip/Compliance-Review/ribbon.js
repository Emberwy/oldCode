var CRMRibbon = window.CRMRibbon || {};

(function () {
    console.log("CRMRibbon");

    this.setNumberOfIssueAndAction = function (a, b) {
        window.parent.numberOfIssue = a;
        window.parent.numberOfAction = b;
    }

    this.SentNotification = function (reviewid, action) {
        var data =
        {
            "aia_reviewid": reviewid,
            "aia_action": action
        }

        // create account record
        Xrm.WebApi.createRecord("aia_aia_crm_notificationlist", data).then(
            function success(result) {
                console.log("Notification created with ID: " + result.id);
            },
            function (error) {
                console.log(error.message);
            }
        );
    }

    //#region code about review form
    this.SaveReview = function (executionContext) {
        var datePass = CRMRibbon.CheckDate(executionContext);
        if (!datePass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewDateErrorMesg, title: "Error Message" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        var statusPass = CRMRibbon.CheckClose(executionContext);
        if (!statusPass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewStatusErrorMesg, title: "Error Message" };
            var alertOptions = { height: 220, width: 300 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        var confirmStrings = { text: CRMSdk.SaveReviewMesg, title: CRMSdk.SaveReviewTitle };
        var confirmOptions = { height: 150, width: 450 };

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();

                    //set modifieddate and don't update permission
                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());
                    executionContext.getAttribute('aia_updatepermission').setValue("No");

                    //get current review guid
                    var myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();

                    if (myId == "") {
                        Xrm.Page.data.save().then((res) => {
                            var parentId = res.savedEntityReference.id;

                            //Send Close Notification
                            var reviewStatus = executionContext.getAttribute('aia_reviewstatus').getValue();
                            if (reviewStatus == 589450003) {
                                CRMRibbon.SentNotification(parentId, "Close");
                            }

                            //Initial teamId with BU/Confidential/RecordStatus
                            var BU = executionContext.getAttribute('aia_businessunit').getValue();
                            var Confidential = executionContext.getAttribute('aia_confidential').getValue();
                            var RecordStatus = CRMSdk.RecordStatus.Draft;
                            var teamId = CRMSdk.getTeamId(BU, Confidential, RecordStatus);

                            // initial permission JSON
                            var permissionJson = [];
                            var recordColl = [];
                            var buconfidentialstatus = BU.toString() + Confidential.toString() + RecordStatus.toString();
                            recordColl.push({
                                "recordId": parentId,
                                "recordType": "reviews"
                            });
                            permissionJson = CRMRibbon.getReviewJsonPermission(recordColl, teamId);
                            var permissionStr = "[" + permissionJson.join(',') + "]";
                            var teamjson = CRMRibbon.getTeamJSON(teamId);

                            //generate Review ID
                            CRMRibbon.getName("Review", function (newName) {
                                var data = {
                                    "aia_name": newName,
                                    "aia_permissionjson": permissionStr,
                                    "aia_revokedpermissionjson": permissionStr,
                                    "aia_countofissues": "0",
                                    "aia_countofactions": "0",
                                    "aia_countofoutstandingissues": "0",
                                    "aia_buconfidentialstatus": buconfidentialstatus,
                                    "aia_teamjson": teamjson,
                                    "aia_revokedteamjson": teamjson,
                                    "aia_updatepermission": "Yes"
                                }

                                // update the record
                                Xrm.WebApi.updateRecord("aia_aia_crm_review", parentId, data).then(function success(result) {
                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedReviewMesg, "INFO", "SaveReview");
                                    window.setTimeout(function () {
                                        Xrm.Page.ui.clearFormNotification("SaveReview");
                                    }, 5000);
                                    Xrm.Page.ui.refresh();
                                    Xrm.Utility.closeProgressIndicator();
                                }, function (error) {
                                });
                            });

                        }, function (error) {
                            Xrm.Utility.closeProgressIndicator();
                        }).catch((err) => {
                        });
                    } else {
                        //update review
                        Xrm.Page.data.save().then((res) => {
                            var parentId = res.savedEntityReference.id;
                            var reviewStatus = executionContext.getAttribute('aia_reviewstatus').getValue();

                            //send close notification when user close current draft review
                            if (reviewStatus == 589450003) {
                                CRMRibbon.SentNotification(parentId, "Close");
                            }

                            //initial teamid with bu/confidential/recordstatus
                            var BU = executionContext.getAttribute('aia_businessunit').getValue();
                            var Confidential = executionContext.getAttribute('aia_confidential').getValue();
                            var RecordStatus = CRMSdk.RecordStatus.Draft;
                            var teamId = CRMSdk.getTeamId(BU, Confidential, RecordStatus);
                            var current_buconfidentialstatus = BU.toString() + Confidential.toString() + RecordStatus.toString();

                            // included id,type in review/issue/action
                            var recordColl = [];

                            var countofIssues = "0";
                            var countofActions = "0";

                            // get review
                            Xrm.WebApi.retrieveRecord("aia_aia_crm_review", parentId, "?$select=aia_permissionjson,aia_aia_crm_reviewid,aia_buconfidentialstatus,aia_teamjson").then(function (review) {
                                var aia_revokedpermissionjson = review.aia_permissionjson;
                                var aia_buconfidentialstatus = review.aia_buconfidentialstatus;
                                var aia_revokedteamjson = review.aia_teamjson;

                                recordColl.push({
                                    "recordId": review.aia_aia_crm_reviewid,
                                    "recordType": "reviews"
                                });

                                // get issues
                                Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + parentId + "'&$select=aia_name,aia_aia_crm_issueid").then(
                                    function success(issues) {
                                        countofIssues = issues.entities.length;
                                        // perform additional operations on retrieved records
                                        for (var i = 0; i < issues.entities.length; i++) {
                                            recordColl.push({
                                                "recordId": issues.entities[i].aia_aia_crm_issueid,
                                                "recordType": "issues"
                                            });
                                        }

                                        // get actions
                                        Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + parentId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                                            function success(actions) {
                                                countofActions = actions.entities.length;
                                                // perform additional operations on retrieved records
                                                for (var i = 0; i < actions.entities.length; i++) {
                                                    recordColl.push({
                                                        "recordId": actions.entities[i].aia_aia_crm_actionid,
                                                        "recordType": "actions"
                                                    });
                                                }

                                                var data;
                                                var teamjson = CRMRibbon.getTeamJSON(teamId);

                                                if (current_buconfidentialstatus == aia_buconfidentialstatus) {
                                                    var data = {
                                                        "aia_countofissues": String(countofIssues),
                                                        "aia_countofactions": String(countofActions)
                                                    }
                                                } else {
                                                    // initial permission JSON
                                                    var permissionJson = [];
                                                    permissionJson = CRMRibbon.getReviewJsonPermission(recordColl, teamId);
                                                    var permissionStr = "[" + permissionJson.join(',') + "]";

                                                    var data = {
                                                        "aia_buconfidentialstatus": current_buconfidentialstatus,
                                                        "aia_teamjson": teamjson,
                                                        "aia_revokedteamjson": aia_revokedteamjson,
                                                        "aia_permissionjson": permissionStr,
                                                        "aia_revokedpermissionjson": aia_revokedpermissionjson,
                                                        "aia_countofissues": String(countofIssues),
                                                        "aia_countofactions": String(countofActions),
                                                        "aia_updatepermission": "Yes"
                                                    }
                                                }

                                                // update the record
                                                Xrm.WebApi.updateRecord("aia_aia_crm_review", parentId, data).then(function success(result) {
                                                    Xrm.Page.data.refresh();
                                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedReviewMesg, "INFO", "SaveReview");
                                                    window.setTimeout(function () {
                                                        Xrm.Page.ui.clearFormNotification("SaveReview");
                                                    }, 5000);
                                                    Xrm.Page.ui.refresh();
                                                    Xrm.Utility.closeProgressIndicator();
                                                }, function (error) {
                                                    console.log("error", error.message);
                                                });
                                            },
                                            function (error) {
                                                console.log(error.message);
                                            }
                                        );
                                    },
                                    function (error) {
                                        console.log(error.message);
                                    }
                                );
                            }, function (error) {
                                console.log(error);
                            });


                        }, function (error) {
                            Xrm.Utility.closeProgressIndicator();
                            console.log(error);
                        }).catch((err) => {
                            console.log(err);
                        });
                    }
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.submitReview = function (executionContext) {
        var datePass = CRMRibbon.CheckDate(executionContext);
        if (!datePass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewDateErrorMesg, title: "Error Message" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        var statusPass = CRMRibbon.CheckClose(executionContext);
        if (!statusPass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewStatusErrorMesg, title: "Error Message" };
            var alertOptions = { height: 220, width: 300 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var confirmStrings = { text: CRMSdk.SubmitReviewMesg, title: CRMSdk.SubmitReviewTitle };
        var confirmOptions = { height: 150, width: 450 };

        if (myId == "") {
            // user should save the review at first, then user can submit the review
            Xrm.Page.ui.setFormNotification(CRMSdk.saveReviewMesg, "ERROR", "submitReview");
            window.setTimeout(function () {
                Xrm.Page.ui.clearFormNotification("submitReview");
            }, 5000);
            return;
        }

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());
                    executionContext.getAttribute('aia_updatepermission').setValue("No");

                    //update review
                    Xrm.Page.data.save().then((res) => {
                        Xrm.Utility.showProgressIndicator();
                        CRMRibbon.SentNotification(myId, "Submit");
                        var BU = executionContext.getAttribute('aia_businessunit').getValue();
                        var Confidential = executionContext.getAttribute('aia_confidential').getValue();
                        var RecordStatus = CRMSdk.RecordStatus.Published;
                        var teamId = CRMSdk.getTeamId(BU, Confidential, RecordStatus);
                        var current_buconfidentialstatus = BU.toString() + Confidential.toString() + RecordStatus.toString();

                        // included id,type in review/issue/action
                        var recordColl = [];

                        var countofIssues = "0";
                        var countofActions = "0";

                        // get review
                        Xrm.WebApi.retrieveRecord("aia_aia_crm_review", myId, "?$select=aia_permissionjson,aia_aia_crm_reviewid,aia_teamjson").then(function (review) {
                            var aia_revokedpermissionjson = review.aia_permissionjson;
                            var aia_revokedteamjson = review.aia_teamjson;
                            recordColl.push({
                                "recordId": review.aia_aia_crm_reviewid,
                                "recordType": "reviews"
                            });

                            // get issues
                            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + myId + "'&$select=aia_name,aia_aia_crm_issueid").then(
                                function success(issues) {
                                    countofIssues = issues.entities.length;
                                    // perform additional operations on retrieved records
                                    for (var i = 0; i < issues.entities.length; i++) {
                                        recordColl.push({
                                            "recordId": issues.entities[i].aia_aia_crm_issueid,
                                            "recordType": "issues"
                                        });
                                    }

                                    // get actions
                                    Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + myId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                                        function success(actions) {
                                            countofActions = actions.entities.length;
                                            // perform additional operations on retrieved records
                                            for (var i = 0; i < actions.entities.length; i++) {
                                                recordColl.push({
                                                    "recordId": actions.entities[i].aia_aia_crm_actionid,
                                                    "recordType": "actions"
                                                });
                                            }

                                            // initial permission JSON
                                            var permissionJson = [];
                                            permissionJson = CRMRibbon.getReviewJsonPermission(recordColl, teamId);
                                            var permissionStr = "[" + permissionJson.join(',') + "]";
                                            var teamjson = CRMRibbon.getTeamJSON(teamId);

                                            var data = {
                                                "aia_buconfidentialstatus": current_buconfidentialstatus,
                                                "aia_teamjson": teamjson,
                                                "aia_revokedteamjson": aia_revokedteamjson,
                                                "aia_permissionjson": permissionStr,
                                                "aia_revokedpermissionjson": aia_revokedpermissionjson,
                                                "aia_countofissues": String(countofIssues),
                                                "aia_countofactions": String(countofActions),
                                                "aia_recordstatus": RecordStatus,
                                                "aia_updatepermission": "Yes"
                                            }

                                            // update the record
                                            Xrm.WebApi.updateRecord("aia_aia_crm_review", myId, data).then(function success(result) {
                                                Xrm.Page.data.refresh().then(function () {
                                                    Xrm.Page.ui.refreshRibbon();
                                                }, function () { });
                                                Xrm.Page.ui.setFormNotification(CRMSdk.SubmitedReviewMesg, "INFO", "submitReview");
                                                window.setTimeout(function () {
                                                    Xrm.Page.ui.clearFormNotification("submitReview");
                                                }, 5000);
                                                Xrm.Page.ui.refresh();
                                                Xrm.Utility.closeProgressIndicator();
                                            }, function (error) {
                                            });
                                        },
                                        function (error) {
                                        }
                                    );
                                },
                                function (error) {
                                }
                            );
                        }, function (error) {
                        });
                    }, function (error) {
                        Xrm.Utility.closeProgressIndicator();
                    }).catch((err) => {
                    });
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.UpdateReview = function (executionContext) {
        var datePass = CRMRibbon.CheckDate(executionContext);
        if (!datePass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewDateErrorMesg, title: "Error Message" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        var statusPass = CRMRibbon.CheckClose(executionContext);
        if (!statusPass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewStatusErrorMesg, title: "Error Message" };
            var alertOptions = { height: 220, width: 300 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        var confirmStrings = { text: CRMSdk.UpdateReviewMesg, title: CRMSdk.UpdateReviewTitle };
        var confirmOptions = { height: 150, width: 450 };

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());
                    executionContext.getAttribute('aia_updatepermission').setValue("No");

                    Xrm.Page.data.save().then((res) => {
                        var parentId = res.savedEntityReference.id;

                        var reviewStatus = executionContext.getAttribute('aia_reviewstatus').getValue();

                        if (reviewStatus == 589450003) {
                            CRMRibbon.SentNotification(parentId, "Close");
                        }

                        var BU = executionContext.getAttribute('aia_businessunit').getValue();
                        var Confidential = executionContext.getAttribute('aia_confidential').getValue();
                        var RecordStatus = CRMSdk.RecordStatus.Published;
                        var teamId = CRMSdk.getTeamId(BU, Confidential, RecordStatus);
                        var current_buconfidentialstatus = BU.toString() + Confidential.toString() + RecordStatus.toString();

                        // included id,type in review/issue/action
                        var recordColl = [];

                        var countofIssues = "0";
                        var countofActions = "0";

                        // get review
                        Xrm.WebApi.retrieveRecord("aia_aia_crm_review", parentId, "?$select=aia_permissionjson,aia_aia_crm_reviewid,aia_buconfidentialstatus,aia_teamjson").then(function (review) {
                            var aia_buconfidentialstatus = review.aia_buconfidentialstatus;
                            var aia_revokedpermissionjson = review.aia_permissionjson;
                            var aia_revokedteamjson = review.aia_teamjson;
                            recordColl.push({
                                "recordId": review.aia_aia_crm_reviewid,
                                "recordType": "reviews"
                            });

                            // get issues
                            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + parentId + "'&$select=aia_name,aia_aia_crm_issueid").then(
                                function success(issues) {
                                    countofIssues = issues.entities.length;
                                    // perform additional operations on retrieved records
                                    for (var i = 0; i < issues.entities.length; i++) {
                                        recordColl.push({
                                            "recordId": issues.entities[i].aia_aia_crm_issueid,
                                            "recordType": "issues"
                                        });
                                    }

                                    // get actions
                                    Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + parentId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                                        function success(actions) {
                                            countofActions = actions.entities.length;
                                            // perform additional operations on retrieved records
                                            for (var i = 0; i < actions.entities.length; i++) {
                                                recordColl.push({
                                                    "recordId": actions.entities[i].aia_aia_crm_actionid,
                                                    "recordType": "actions"
                                                });
                                            }

                                            var data;

                                            if (current_buconfidentialstatus == aia_buconfidentialstatus) {
                                                data = {
                                                    "aia_countofissues": String(countofIssues),
                                                    "aia_countofactions": String(countofActions)
                                                }
                                            } else {
                                                // initial permission JSON
                                                var permissionJson = [];
                                                permissionJson = CRMRibbon.getReviewJsonPermission(recordColl, teamId);
                                                var permissionStr = "[" + permissionJson.join(',') + "]";
                                                var teamjson = CRMRibbon.getTeamJSON(teamId);

                                                data = {
                                                    "aia_buconfidentialstatus": current_buconfidentialstatus,
                                                    "aia_teamjson": teamjson,
                                                    "aia_revokedteamjson": aia_revokedteamjson,
                                                    "aia_permissionjson": permissionStr,
                                                    "aia_revokedpermissionjson": aia_revokedpermissionjson,
                                                    "aia_countofissues": String(countofIssues),
                                                    "aia_countofactions": String(countofActions),
                                                    "aia_updatepermission": "Yes"
                                                }
                                            }

                                            // update the record
                                            Xrm.WebApi.updateRecord("aia_aia_crm_review", parentId, data).then(function success(result) {
                                                Xrm.Page.data.refresh();
                                                Xrm.Page.ui.setFormNotification(CRMSdk.UpdatedReviewMesg, "INFO", "UpdateReview");
                                                window.setTimeout(function () {
                                                    Xrm.Page.ui.clearFormNotification("UpdateReview");
                                                }, 5000);
                                                Xrm.Page.ui.refresh();
                                                Xrm.Utility.closeProgressIndicator();
                                            }, function (error) {
                                                console.log("error", error.message);
                                            });
                                        },
                                        function (error) {
                                            console.log(error.message);
                                        }
                                    );
                                },
                                function (error) {
                                    console.log(error.message);
                                }
                            );
                        }, function (error) {
                            console.log(error);
                        });

                    }, function (error) {
                        Xrm.Utility.closeProgressIndicator();
                        console.log(error);
                    }).catch((err) => {
                        console.log(err);
                    });
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    //check Review Start Date and Review End Date
    this.CheckDate = function (executionContext) {
        var result = true;
        var startDate = executionContext.getAttribute('aia_reviewstartdate').getValue();
        var endDate = executionContext.getAttribute('aia_reviewenddate').getValue();
        if (startDate != null && endDate != null && endDate < startDate) {
            result = false;
        }

        return result;
    }

    //if user wants to close the review, user should make Finding, Issue and Action is not Open
    this.CheckClose = function (executionContext) {
        var result = true;
        //close = 589450003
        var reviewStatus = executionContext.getAttribute('aia_reviewstatus').getValue();
        //close = 589450001
        var findingStatus = executionContext.getAttribute('aia_findingsstatus').getValue();

        if (window.parent.numberOfIssue != undefined && window.parent.numberOfAction != undefined && (reviewStatus == 589450003 || findingStatus == 589450001)) {
            if (window.parent.numberOfIssue != 0 || window.parent.numberOfAction != 0 || findingStatus != 589450001) {
                result = false;
            }
        }

        return result;
    }

    this.CheckCloseWhenClose = function (executionContext) {
        var result = true;

        //close = 589450001
        var findingStatus = executionContext.getAttribute('aia_findingsstatus').getValue();
        if (findingStatus != 589450001) {
            result = false;
        }

        if (window.parent.numberOfIssue != undefined && window.parent.numberOfAction != undefined && (window.parent.numberOfIssue != 0 || window.parent.numberOfAction != 0)) {
            result = false;
        }

        return result;
    }

    this.CloseReview = function (executionContext) {
        var confirmStrings = { text: CRMSdk.CloseReviewMesg, title: CRMSdk.CloseReviewTitle };
        var confirmOptions = { height: 150, width: 450 };
        let ReviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var statusPass = CRMRibbon.CheckCloseWhenClose(executionContext);

        if (!statusPass) {
            var alertStrings = { confirmButtonLabel: "OK", text: CRMSdk.saveReviewStatusErrorMesg, title: "Error Message" };
            var alertOptions = { height: 220, width: 300 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        executionContext.getControl('aia_reviewstatus').getAttribute().setValue(CRMSdk.Status.Closed);

        var BU = executionContext.getAttribute('aia_businessunit').getValue();
        var Confidential = executionContext.getAttribute('aia_confidential').getValue();
        var RecordStatus = executionContext.getAttribute('aia_recordstatus').getValue();
        var aia_buconfidentialstatus = executionContext.getAttribute('aia_buconfidentialstatus').getValue();
        var current_buconfidentialstatus = BU.toString() + Confidential.toString() + RecordStatus.toString();

        if (current_buconfidentialstatus != aia_buconfidentialstatus) {
            var alertStrings = { confirmButtonLabel: "OK", text: "Please update 'Business Unit' and 'Restricted Access' before Close current Review.", title: "Error Message" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
            return;
        }

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    Xrm.Page.data.save().then((res) => {
                        CRMRibbon.SentNotification(ReviewId, "Close");

                        Xrm.Page.data.refresh().then(function () {
                            Xrm.Page.ui.refreshRibbon();
                        }, function () { });

                        Xrm.Page.ui.setFormNotification(CRMSdk.ClosedReviewMesg, "INFO", "CloseReview");
                        window.setTimeout(function () {
                            Xrm.Page.ui.clearFormNotification("CloseReview");
                        }, 5000);
                        Xrm.Page.ui.refresh()
                        Xrm.Utility.closeProgressIndicator();
                        // window.location.reload();
                        Xrm.Utility.closeProgressIndicator().then(function () {
                            window.location.reload();
                        });

                    }, function (error) {
                        Xrm.Utility.closeProgressIndicator();
                        console.log(error);
                    }).catch((err) => {
                        console.log(err);
                    });
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.ReopenReview = function () {
        let parentId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var confirmStrings = { text: CRMSdk.ReopenReviewMesg, title: CRMSdk.ReopenReviewTitle };
        var confirmOptions = { height: 150, width: 450 };

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    var data = {
                        "aia_reviewstatus": CRMSdk.Status.InProgress,
                        "aia_iscloseed": false
                    }

                    // update the record
                    Xrm.WebApi.updateRecord("aia_aia_crm_review", parentId, data).then(function success(result) {
                        Xrm.Page.data.refresh().then(function () {
                            Xrm.Page.ui.refreshRibbon();
                        }, function () { });

                        Xrm.Page.ui.setFormNotification(CRMSdk.ReopenedReviewMesg, "INFO", "ReopenReview");
                        window.setTimeout(function () {
                            Xrm.Page.ui.clearFormNotification("ReopenReview");
                        }, 5000);
                        Xrm.Page.ui.refresh()
                        Xrm.Utility.closeProgressIndicator();
                    }, function (error) {
                        console.log("error", error.message);
                    });
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.DeleteReview = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var confirmStrings = { text: CRMSdk.DeleteReviewMesg, title: CRMSdk.DeleteReviewTitle };
        var confirmOptions = { height: 150, width: 450 };

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    Xrm.WebApi.deleteRecord("aia_aia_crm_review", myId).then(
                        function success(result) {
                            Xrm.Utility.closeProgressIndicator();
                            var pageInput = {
                                pageType: "entitylist",
                                entityName: "aia_aia_crm_review",
                                viewId: CRMSdk.ReviewViews.defaultView
                            };

                            Xrm.Navigation.navigateTo(pageInput).then(
                                function success() {
                                },
                                function error() {
                                }
                            );
                        },
                        function (error) {
                            console.log(error.message);
                        }
                    );
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.EnableSaveReview = function (executionContext) {
        var RecordStatus = executionContext.getAttribute('aia_recordstatus').getValue();
        if (RecordStatus != CRMSdk.RecordStatus.Published && executionContext.getControl('aia_reviewstatus').getDisabled() == false) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableSubmitReview = function (executionContext) {
        var RecordStatus = executionContext.getAttribute('aia_recordstatus').getValue();
        if (RecordStatus == CRMSdk.RecordStatus.Draft && executionContext.getControl('aia_reviewstatus').getDisabled() == false) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableUpdateReview = function (executionContext) {
        var RecordStatus = executionContext.getAttribute('aia_recordstatus').getValue();
        if (RecordStatus == CRMSdk.RecordStatus.Published && executionContext.getControl('aia_reviewstatus').getDisabled() == false) {//ReviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableCloseReview = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();

        if (myId != "" && executionContext.getControl('aia_reviewstatus').getDisabled() == false) {//ReviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableReopenReview = function (executionContext) {
        var ReviewStatus = executionContext.getAttribute('aia_reviewstatus').getValue();
        if (executionContext.getControl('aia_reviewstatus').getDisabled() == true && ReviewStatus == CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableDeleteReview = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();

        if (myId != "") {
            return true;
        }
        else {
            return false;
        }
    }
    //#endregion

    //#region code about issue form
    this.saveIssue = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var ReviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id;
        var confirmStrings = { text: CRMSdk.SaveIssueMesg, title: CRMSdk.SaveIssueTitle };
        var confirmOptions = { height: 150, width: 450 };

        //if you want to close issue, make sure all actions are closed
        var IssueStatus = executionContext.getAttribute('aia_issuestatus').getValue();
        //close = 589450001
        if (IssueStatus == 589450001 && myId != "") {
            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$select=aia_name&$filter=_aia_relatedissue_value eq '" + myId + "' and aia_actionstatus eq 589450000").then(
                function success(result) {
                    if (result.entities.length != 0) {
                        //there is opened action when user wants to close the issue
                        var alertStrings = { confirmButtonLabel: "OK", text: "There are one or more open actions, please close all actions before closing the issue.", title: "Error Message" };
                        var alertOptions = { height: 120, width: 260 };
                        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                        return;
                    } else {
                        //save issue
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                            function (success) {
                                if (success.confirmed) {
                                    Xrm.Utility.showProgressIndicator();
                                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                                    if (myId == "") {
                                        Xrm.Page.data.save().then((res) => {
                                            var parentId = res.savedEntityReference.id;
                                            CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", parentId, "Insert");
                                            // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                            CRMRibbon.getName("Issue", function (newName) {
                                                var data = {
                                                    "aia_name": newName
                                                }

                                                // update the record
                                                Xrm.WebApi.updateRecord("aia_aia_crm_issue", parentId, data).then(function success(result) {
                                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                                    window.setTimeout(function () {
                                                        Xrm.Page.ui.clearFormNotification("saveIssue");
                                                    }, 5000);
                                                    Xrm.Page.data.refresh();
                                                    Xrm.Utility.closeProgressIndicator();
                                                }, function (error) {
                                                    console.log("error", error.message);
                                                });
                                            });
                                        }, function (error) {
                                            Xrm.Utility.closeProgressIndicator();
                                            console.log(error);
                                        })
                                    } else {
                                        Xrm.Page.data.save().then((res) => {
                                            if (IssueStatus != localStorage.getItem("IssueStatus")) {
                                                CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", myId, "Update");
                                            }
                                            // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                            Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                            window.setTimeout(function () {
                                                Xrm.Page.ui.clearFormNotification("saveIssue");
                                            }, 5000);
                                            Xrm.Page.data.refresh();
                                            Xrm.Utility.closeProgressIndicator();
                                        }, function (error) {
                                            Xrm.Utility.closeProgressIndicator();
                                            console.log(error);
                                        })
                                    }
                                }
                                else
                                    console.log("Dialog closed using Cancel button or X.");
                            });
                    }
                },
                function (error) {
                    console.log(error.message);
                }
            )
        }
        else {
            //save issue
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        Xrm.Utility.showProgressIndicator();
                        executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                        if (myId == "") {
                            Xrm.Page.data.save().then((res) => {
                                // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                var parentId = res.savedEntityReference.id;
                                CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", parentId, "Insert");

                                CRMRibbon.getName("Issue", function (newName) {
                                    var data = {
                                        "aia_name": newName
                                    }

                                    // update the record
                                    Xrm.WebApi.updateRecord("aia_aia_crm_issue", parentId, data).then(function success(result) {
                                        Xrm.Page.data.refresh();
                                        Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                        window.setTimeout(function () {
                                            Xrm.Page.ui.clearFormNotification("saveIssue");
                                        }, 5000);
                                        Xrm.Utility.closeProgressIndicator();
                                    }, function (error) {
                                        console.log("error", error.message);
                                    });
                                });
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        } else {
                            Xrm.Page.data.save().then((res) => {
                                if (IssueStatus != localStorage.getItem("IssueStatus")) {
                                    CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", myId, "Update");
                                }
                                // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                Xrm.Page.data.refresh();
                                Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                window.setTimeout(function () {
                                    Xrm.Page.ui.clearFormNotification("saveIssue");
                                }, 5000);
                                Xrm.Utility.closeProgressIndicator();
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        }
                    }
                    else
                        console.log("Dialog closed using Cancel button or X.");
                });
        }


    }

    this.SaveCloseIssue = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var ReviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id;
        var confirmStrings = { text: CRMSdk.SaveIssueMesg, title: CRMSdk.SaveIssueTitle };
        var confirmOptions = { height: 150, width: 450 };

        //if you want to close issue, make sure all actions are closed
        var IssueStatus = executionContext.getAttribute('aia_issuestatus').getValue();
        //close = 589450001
        if (IssueStatus == 589450001 && myId != "") {
            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$select=aia_name&$filter=_aia_relatedissue_value eq '" + myId + "' and aia_actionstatus eq 589450000").then(
                function success(actions) {
                    if (actions.entities.length != 0) {
                        //there is opened action when user wants to close the issue
                        var alertStrings = { confirmButtonLabel: "OK", text: "There are one or more open actions, please close all actions before closing the issue.", title: "Error Message" };
                        var alertOptions = { height: 120, width: 260 };
                        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions);
                        return;
                    } else {
                        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                            function (success) {
                                if (success.confirmed) {
                                    Xrm.Utility.showProgressIndicator();
                                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                                    if (myId == "") {
                                        Xrm.Page.data.save().then((res) => {
                                            // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                            var parentId = res.savedEntityReference.id;
                                            CRMRibbon.getName("Issue", function (newName) {
                                                var data = {
                                                    "aia_name": newName
                                                }

                                                CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", parentId, "Insert");

                                                // update the record
                                                Xrm.WebApi.updateRecord("aia_aia_crm_issue", parentId, data).then(function success(result) {
                                                    Xrm.Page.data.refresh();
                                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                                    window.setTimeout(function () {
                                                        Xrm.Page.ui.clearFormNotification("saveIssue");
                                                    }, 5000);
                                                    Xrm.Utility.closeProgressIndicator();
                                                    Xrm.Page.ui.close();
                                                }, function (error) {
                                                    console.log("error", error.message);
                                                });
                                            });
                                        }, function (error) {
                                            Xrm.Utility.closeProgressIndicator();
                                            console.log(error);
                                        })
                                    } else {
                                        Xrm.Page.data.save().then((res) => {
                                            if (IssueStatus != localStorage.getItem("IssueStatus")) {
                                                CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", myId, "Update");
                                            }
                                            // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                            Xrm.Page.data.refresh();
                                            Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                            window.setTimeout(function () {
                                                Xrm.Page.ui.clearFormNotification("saveIssue");
                                            }, 5000);
                                            Xrm.Utility.closeProgressIndicator();
                                            Xrm.Page.ui.close();
                                        }, function (error) {
                                            Xrm.Utility.closeProgressIndicator();
                                            console.log(error);
                                        })
                                    }
                                }
                                else
                                    console.log("Dialog closed using Cancel button or X.");
                            });
                    }
                })
        } else {
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        Xrm.Utility.showProgressIndicator();
                        executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                        if (myId == "") {
                            Xrm.Page.data.save().then((res) => {
                                // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                var parentId = res.savedEntityReference.id;
                                CRMRibbon.getName("Issue", function (newName) {
                                    var data = {
                                        "aia_name": newName
                                    }
                                    CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", parentId, "Insert");

                                    // update the record
                                    Xrm.WebApi.updateRecord("aia_aia_crm_issue", parentId, data).then(function success(result) {
                                        Xrm.Page.data.refresh();
                                        Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                        window.setTimeout(function () {
                                            Xrm.Page.ui.clearFormNotification("saveIssue");
                                        }, 5000);
                                        Xrm.Utility.closeProgressIndicator();
                                        Xrm.Page.ui.close();
                                    }, function (error) {
                                        console.log("error", error.message);
                                    });
                                });
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        } else {
                            Xrm.Page.data.save().then((res) => {
                                if (IssueStatus != localStorage.getItem("IssueStatus")) {
                                    CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Issue", myId, "Update");
                                }
                                // CRMRibbon.updateCountOfOutcomeIssues(ReviewId);
                                Xrm.Page.data.refresh();
                                Xrm.Page.ui.setFormNotification(CRMSdk.SavedIssueMesg, "INFO", "saveIssue");
                                window.setTimeout(function () {
                                    Xrm.Page.ui.clearFormNotification("saveIssue");
                                }, 5000);
                                Xrm.Utility.closeProgressIndicator();
                                Xrm.Page.ui.close();
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        }
                    }
                    else
                        console.log("Dialog closed using Cancel button or X.");
                });
        }
    }

    this.DeleteIssue = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var confirmStrings = { text: CRMSdk.DeleteIssueMesg, title: CRMSdk.DeleteIssueTitle };
        var confirmOptions = { height: 150, width: 450 };
        var reviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id;

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    CRMRibbon.InsertToAIA_CRM_IARecord(reviewId, "Issue", myId, "Delete");
                    Xrm.WebApi.deleteRecord("aia_aia_crm_issue", myId).then(
                        function success(result) {
                            // CRMRibbon.updateCountOfOutcomeIssues(reviewId);
                            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_aia_crm_issueid").then(
                                function success(issues) {
                                    countofIssues = issues.entities.length;
                                    // update the record
                                    var data = {
                                        "aia_countofissues": String(countofIssues)
                                    }

                                    // update the record
                                    Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                                        console.log("success", countofActions);
                                    }, function (error) {
                                        console.log("error", error.message);
                                    });
                                },
                                function (error) {
                                    console.log(error.message);
                                }
                            );
                            Xrm.Utility.closeProgressIndicator();
                            Xrm.Page.ui.close();
                        },
                        function (error) {
                            console.log(error.message);
                        }
                    );
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.EnableSaveIssue = async function (executionContext) {
        var inputdata = Xrm.Utility.getPageContext().input.data;
        if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
            return false;
        }

        var review = executionContext.getAttribute('aia_relatedreview').getValue();
        var reviewId = review[0].id.replace(/[\{\}]*/g, "");

        var record = await Xrm.WebApi.retrieveRecord("aia_aia_crm_review", reviewId, "?$select=aia_reviewstatus");
        var reviewStatus = record.aia_reviewstatus;

        if (reviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableDeleteIssue = async function (executionContext) {
        var inputdata = Xrm.Utility.getPageContext().input.data;
        if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
            return false;
        }

        var review = executionContext.getAttribute('aia_relatedreview').getValue();
        var reviewId = review[0].id.replace(/[\{\}]*/g, "");

        var record = await Xrm.WebApi.retrieveRecord("aia_aia_crm_review", reviewId, "?$select=aia_reviewstatus");
        var reviewStatus = record.aia_reviewstatus;

        if (reviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    // this.updateCountOfOutcomeIssues = function (reviewId) {
    //     Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + reviewId + "' and aia_issuestatus eq 589450000&$select=aia_name,aia_aia_crm_issueid,aia_issuestatus").then(
    //         function success(issues) {
    //             countofOutcomeIssues = issues.entities.length;
    //             // update the record
    //             var data = {
    //                 "aia_countofoutstandingissues": String(countofOutcomeIssues)
    //             }

    //             // update the record
    //             Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
    //                 console.log("success", countofOutcomeIssues);
    //             }, function (error) {
    //                 console.log("error", error.message);
    //             });
    //         },
    //         function (error) {
    //             console.log(error.message);
    //         }
    //     );
    // }
    //#endregion

    //#region code about issue subgrid
    this.addIssue = function (executionContext) {
        let reviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        let reviewName = Xrm.Page.data.entity.getEntityReference().name;
        let entityName = Xrm.Page.data.entity.getEntityReference().entityType;

        if (reviewId == "") {
            executionContext.ui.setFormNotification("Please save the review at first.", "INFO", "AddIusse");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("AddIusse");
            }, 5000)
        }
        else {
            var pageInput = {
                pageType: "entityrecord",
                entityName: "aia_aia_crm_issue",
                data: { "reviewId": reviewId, "reviewName": reviewName, "entityName": entityName }
            };

            var navigationOptions = {
                target: 2,
                height: { value: 80, unit: "%" },
                width: { value: 70, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                function success(result) {
                    // Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_aia_crm_issueid,aia_issuestatus").then(
                    //     function success(issues) {
                    //         var countofIssues = issues.entities.length;
                    //         // update the record
                    //         var data = {
                    //             "aia_countofissues": String(countofIssues)
                    //         }

                    //         // update the record
                    //         Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                    //             console.log("success", countofIssues);
                    //         }, function (error) {
                    //             console.log("error", error.message);
                    //         });
                    //     },
                    //     function (error) {
                    //         console.log(error.message);
                    //     }
                    // );
                    var subgrid = executionContext.getControl("tab_issue_subgrid");
                    subgrid.refresh();
                    executionContext.getControl("WebResource_journeybar").getContentWindow().then(r => r.location.reload());
                },
                function error() {
                }
            );
        }
    }

    this.EditIssue = function (executionContext) {
        const selectedRows = executionContext.getControl("tab_issue_subgrid").getGrid().getSelectedRows().getAll();

        if (selectedRows.length != 1) {
            executionContext.ui.setFormNotification("Please select an item for editing", "INFO", "EditIssue");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("EditIssue");
            }, 5000);
            return;
        }

        var selectedId = selectedRows[0]._entityId.guid;;
        let reviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();

        var pageInput = {
            pageType: "entityrecord",
            entityName: "aia_aia_crm_issue",
            entityId: selectedId
        };

        var navigationOptions = {
            target: 2,
            height: { value: 80, unit: "%" },
            width: { value: 70, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function success(result) {
                // Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_issue", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_aia_crm_issueid,aia_issuestatus").then(
                //     function success(issues) {
                //         var countofIssues = issues.entities.length;
                //         // update the record
                //         var data = {
                //             "aia_countofissues": String(countofIssues)
                //         }

                //         // update the record
                //         Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                //             console.log("success", countofIssues);
                //         }, function (error) {
                //             console.log("error", error.message);
                //         });
                //     },
                //     function (error) {
                //         console.log(error.message);
                //     }
                // );
                var subgrid = executionContext.getControl("tab_issue_subgrid");
                subgrid.refresh();
                executionContext.getControl("WebResource_journeybar").getContentWindow().then(r => r.location.reload());
            },
            function error() {
            }
        );
    }

    this.ViewIssue = function (executionContext) {
        const selectedRows = executionContext.getControl("tab_issue_subgrid").getGrid().getSelectedRows().getAll();

        if (selectedRows.length != 1) {
            executionContext.ui.setFormNotification("Please select an item for editing", "INFO", "EditIssue");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("EditIssue");
            }, 5000);
            return;
        }

        var selectedId = selectedRows[0]._entityId.guid;;

        var pageInput = {
            pageType: "entityrecord",
            entityName: "aia_aia_crm_issue",
            entityId: selectedId,
            data: { "view": true }
        };

        var navigationOptions = {
            target: 2,
            height: { value: 80, unit: "%" },
            width: { value: 70, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function success(result) {
                var subgrid = executionContext.getControl("tab_issue_subgrid");
                subgrid.refresh();
            },
            function error() {
            }
        );
    }

    this.CreateActionInIssue = function (executionContext) {
        const selectedRows = executionContext.getControl("tab_issue_subgrid").getGrid().getSelectedRows().getAll();

        if (selectedRows.length != 1) {
            executionContext.ui.setFormNotification("Please select an item for editing", "INFO", "EditIssue");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("EditIssue");
            }, 5000);
            return;
        }
        var selectedItem = selectedRows[0].entityReference;

        let reviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        let reviewName = Xrm.Page.data.entity.getEntityReference().name;
        let entityName = Xrm.Page.data.entity.getEntityReference().entityType;
        let issueStatus = selectedRows[0].data.entity.attributes.get("aia_issuestatus").getValue();

        if (issueStatus == "589450001") {
            executionContext.ui.setFormNotification("You can't create action base on a closed issue.", "ERROR", "AddAction");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("AddAction");
            }, 5000)
            return;
        }

        if (reviewId == "") {
            executionContext.ui.setFormNotification("Please save the review at first.", "INFO", "AddAction");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("AddAction");
            }, 5000)
        }
        else {

            let issueTitle = selectedRows[0].data.entity.attributes.get("aia_issuetitle").getValue();
            var pageInput = {
                pageType: "entityrecord",
                entityName: "aia_aia_crm_action",
                data: { "reviewId": reviewId, "reviewName": reviewName, "entityName": entityName, "issueId": selectedItem.id, "issueName": selectedItem.name, "issueEntity": selectedItem.entityType, "issueTitle": issueTitle }
            };

            var navigationOptions = {
                target: 2,
                height: { value: 80, unit: "%" },
                width: { value: 70, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                function success(result) {
                    // Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                    //     function success(actions) {
                    //         countofActions = actions.entities.length;
                    //         // update the record
                    //         var data = {
                    //             "aia_countofactions": String(countofActions)
                    //         }

                    //         // update the record
                    //         Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                    //             console.log("success", countofActions);
                    //         }, function (error) {
                    //             console.log("error", error.message);
                    //         });

                    //         //initial target close date
                    //         var targetCloseDate = executionContext.getAttribute('aia_targetclosedate').getValue();
                    //         var actualCloseDate = executionContext.getAttribute('aia_actualcloseddate').getValue();
                    //         if (reviewId != "") {
                    //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_targetclosedate&$orderby=aia_targetclosedate desc&$top=2").then(
                    //                 function success(actions) {
                    //                     console.log("actions", actions);
                    //                     if (actions.entities.length > 0) {
                    //                         var tdate = new Date(actions.entities[0].aia_targetclosedate);
                    //                         if (targetCloseDate == null || (targetCloseDate != null && new Date(targetCloseDate) < tdate)) {
                    //                             executionContext.getAttribute('aia_targetclosedate').setValue(tdate);
                    //                         }
                    //                     }
                    //                 },
                    //                 function (error) {
                    //                     console.log(error.message);
                    //                 }
                    //             );
                    //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_actualcloseddate&$orderby=aia_actualcloseddate desc&$top=2").then(
                    //                 function success(actions) {
                    //                     console.log("actions", actions);
                    //                     if (actions.entities.length > 0) {
                    //                         var tdate = new Date(actions.entities[0].aia_actualcloseddate);
                    //                         if (actualCloseDate == null || (actualCloseDate != null && new Date(actualCloseDate) < tdate)) {
                    //                             executionContext.getAttribute('aia_actualcloseddate').setValue(tdate);
                    //                         }
                    //                     }
                    //                 },
                    //                 function (error) {
                    //                     console.log(error.message);
                    //                 }
                    //             );
                    //         }
                    //     },
                    //     function (error) {
                    //         console.log(error.message);
                    //     }
                    // );

                    var subgrid = executionContext.getControl("tab_action_subgrid");
                    subgrid.refresh();
                    executionContext.getControl("WebResource_journeybar").getContentWindow().then(r => r.location.reload());
                },
                function error() {
                }
            );
        }
    }

    this.EnableAddIssue = function (executionContext) {
        var review = executionContext.getAttribute("aia_reviewstatus").getValue();
        var returnvalue = false;

        if (review != CRMSdk.Status.Closed) {
            returnvalue = true;
        }

        return returnvalue;
    }

    this.EnableEditIssue = function (executionContext) {
        var review = executionContext.getAttribute("aia_reviewstatus").getValue();
        var returnvalue = false;

        if (review != CRMSdk.Status.Closed) {
            returnvalue = true;
        }

        return returnvalue;
    }

    this.EnableCreateActionInIssue = function (executionContext) {
        var review = executionContext.getAttribute("aia_reviewstatus").getValue();
        var returnvalue = false;

        if (review != CRMSdk.Status.Closed) {
            returnvalue = true;
        }

        return returnvalue;
    }
    //#endregion

    //#region code about action form
    this.saveAction = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var ReviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id;
        var confirmStrings = { text: CRMSdk.SaveActionMesg, title: CRMSdk.SaveActionTitle };
        var confirmOptions = { height: 150, width: 450 };

        var ActionStatus = executionContext.getAttribute('aia_actionstatus').getValue();


        var actionOwners = executionContext.getAttribute("aia_actionownersjson").getValue();
        if (actionOwners == null || actionOwners == "" || actionOwners == "[]") {
            Xrm.Page.ui.setFormNotification("Action Owner(s) can't be empty", "ERROR", "saveAction");
            window.setTimeout(function () {
                Xrm.Page.ui.clearFormNotification("saveAction");
            }, 5000);
            return;
        }

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                    if (myId == "") {
                        Xrm.Page.data.save().then((res) => {
                            var parentId = res.savedEntityReference.id;
                            CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Action", parentId, "Insert");
                            CRMRibbon.getName("Action", function (newName) {
                                var data = {
                                    "aia_name": newName,
                                    "aia_createaction": "Created"
                                }

                                // update the record
                                Xrm.WebApi.updateRecord("aia_aia_crm_action", parentId, data).then(function success(result) {
                                    Xrm.Page.data.refresh();
                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedActionMesg, "INFO", "saveAction");
                                    window.setTimeout(function () {
                                        Xrm.Page.ui.clearFormNotification("saveAction");
                                    }, 5000);
                                    Xrm.Utility.closeProgressIndicator();
                                }, function (error) {
                                    console.log("error", error.message);
                                });
                            });
                        }, function (error) {
                            Xrm.Utility.closeProgressIndicator();
                            console.log(error);
                        })
                    } else {
                        Xrm.WebApi.retrieveRecord("aia_aia_crm_action", myId, "?$select=_aia_actionowner_value,_aia_lastactionowner_value").then(function success(action) {
                            var actionOwner = action._aia_actionowner_value;
                            var lastActionOwner = action._aia_lastactionowner_value;
                            if (actionOwner != lastActionOwner) {
                                var actionOwnerName = action["_aia_actionowner_value@OData.Community.Display.V1.FormattedValue"];
                                let lookupData = [
                                    {
                                        "entityType": "systemuser",
                                        "id": actionOwner,
                                        "name": actionOwnerName
                                    }
                                ]
                                executionContext.getAttribute('aia_lastactionowner').setValue(lookupData);
                            }
                            Xrm.Page.data.save().then((res) => {
                                Xrm.Page.data.refresh();
                                Xrm.Page.ui.setFormNotification(CRMSdk.SavedActionMesg, "INFO", "saveAction");
                                if (ActionStatus != localStorage.getItem("ActionStatus")) {
                                    CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Action", myId, "Update");
                                }
                                window.setTimeout(function () {
                                    Xrm.Page.ui.clearFormNotification("saveAction");
                                }, 5000);
                                Xrm.Utility.closeProgressIndicator();
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        }, function (error) {
                            console.log("error", error.message);
                        });

                    }
                }
                else
                    console.log("Dialog closed using Cancel button or X.");

            });
    }

    this.SaveCloseAction = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var ReviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id;
        var confirmStrings = { text: CRMSdk.SaveActionMesg, title: CRMSdk.SaveActionTitle };
        var confirmOptions = { height: 150, width: 450 };
        var ActionStatus = executionContext.getAttribute('aia_actionstatus').getValue();

        var actionOwners = executionContext.getAttribute("aia_actionownersjson").getValue();
        if (actionOwners == null || actionOwners == "" || actionOwners == "[]") {
            Xrm.Page.ui.setFormNotification("Action Owner(s) can't be empty", "ERROR", "saveAction");
            window.setTimeout(function () {
                Xrm.Page.ui.clearFormNotification("saveAction");
            }, 5000);
            return;
        }

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    executionContext.getAttribute('aia_modifieddate').setValue(new Date());

                    if (myId == "") {
                        Xrm.Page.data.save().then((res) => {
                            var parentId = res.savedEntityReference.id;
                            CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Action", parentId, "Insert");
                            CRMRibbon.getName("Action", function (newName) {
                                var data = {
                                    "aia_name": newName,
                                    "aia_createaction": "Created"
                                }

                                // update the record
                                Xrm.WebApi.updateRecord("aia_aia_crm_action", parentId, data).then(function success(result) {
                                    Xrm.Page.data.refresh();
                                    Xrm.Page.ui.setFormNotification(CRMSdk.SavedActionMesg, "INFO", "saveAction");
                                    window.setTimeout(function () {
                                        Xrm.Page.ui.clearFormNotification("saveAction");
                                    }, 5000);
                                    Xrm.Utility.closeProgressIndicator();
                                    Xrm.Page.ui.close();
                                }, function (error) {
                                    console.log("error", error.message);
                                });
                            });
                        }, function (error) {
                            Xrm.Utility.closeProgressIndicator();
                            console.log(error);
                        })
                    } else {
                        Xrm.WebApi.retrieveRecord("aia_aia_crm_action", myId, "?$select=_aia_actionowner_value,_aia_lastactionowner_value").then(function success(action) {
                            var actionOwner = action._aia_actionowner_value;
                            var lastActionOwner = action._aia_lastactionowner_value;
                            if (actionOwner != lastActionOwner) {
                                var actionOwnerName = action["_aia_actionowner_value@OData.Community.Display.V1.FormattedValue"];
                                let lookupData = [
                                    {
                                        "entityType": "systemuser",
                                        "id": actionOwner,
                                        "name": actionOwnerName
                                    }
                                ]
                                executionContext.getAttribute('aia_lastactionowner').setValue(lookupData);
                            }
                            Xrm.Page.data.save().then((res) => {
                                Xrm.Page.data.refresh();
                                if (ActionStatus != localStorage.getItem("ActionStatus")) {
                                    CRMRibbon.InsertToAIA_CRM_IARecord(ReviewId, "Action", myId, "Update");
                                }
                                Xrm.Page.ui.setFormNotification(CRMSdk.SavedActionMesg, "INFO", "saveAction");
                                window.setTimeout(function () {
                                    Xrm.Page.ui.clearFormNotification("saveAction");
                                }, 5000);
                                Xrm.Utility.closeProgressIndicator();
                                Xrm.Page.ui.close();
                            }, function (error) {
                                Xrm.Utility.closeProgressIndicator();
                                console.log(error);
                            })
                        }, function (error) {
                            console.log("error", error.message);
                        });

                    }
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.DeleteAction = function (executionContext) {
        let myId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var confirmStrings = { text: CRMSdk.DeleteActionMesg, title: CRMSdk.DeleteActionTitle };
        var confirmOptions = { height: 150, width: 450 };
        var reviewId = executionContext.getAttribute('aia_relatedreview').getValue()[0].id.replace(/[\{\}]*/g, "").toLowerCase();
        // var issueId = executionContext.getAttribute('aia_relatedissue').getValue()[0].id.replace(/[\{\}]*/g, "").toLowerCase();
        // var actionOwner = executionContext.getAttribute('aia_actionowner').getValue()[0].id.replace(/[\{\}]*/g, "").toLowerCase();

        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    Xrm.Utility.showProgressIndicator();
                    CRMRibbon.InsertToAIA_CRM_IARecord(reviewId, "Action", myId, "Delete");
                    Xrm.WebApi.deleteRecord("aia_aia_crm_action", myId).then(
                        function success(result) {

                            // var data =
                            // {
                            //     "aia_reviewid": reviewId,
                            //     "aia_issueid": issueId,
                            //     "aia_actionownerid": actionOwner
                            // }

                            // // create account record
                            // Xrm.WebApi.createRecord("aia_aia_crm_actiondeletehistory", data).then(
                            //     function success(result) {
                            //         console.log("Notification created with ID: " + result.id);
                            //     },
                            //     function (error) {
                            //         console.log(error.message);
                            //     }
                            // );
                            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                                function success(actions) {
                                    countofActions = actions.entities.length;
                                    // update the record
                                    var data = {
                                        "aia_countofactions": String(countofActions)
                                    }

                                    // update the record
                                    Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                                        console.log("success", countofActions);
                                    }, function (error) {
                                        console.log("error", error.message);
                                    });
                                },
                                function (error) {
                                    console.log(error.message);
                                }
                            );
                            Xrm.Utility.closeProgressIndicator();
                            Xrm.Page.ui.close();
                        },
                        function (error) {
                            console.log(error.message);
                        }
                    );
                }
                else
                    console.log("Dialog closed using Cancel button or X.");
            });
    }

    this.EnableSaveAction = async function (executionContext) {
        var inputdata = Xrm.Utility.getPageContext().input.data;
        if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
            return false;
        }

        var review = executionContext.getAttribute('aia_relatedreview').getValue();
        var reviewId = review[0].id.replace(/[\{\}]*/g, "");

        var record = await Xrm.WebApi.retrieveRecord("aia_aia_crm_review", reviewId, "?$select=aia_reviewstatus");
        var reviewStatus = record.aia_reviewstatus;

        if (reviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }

    this.EnableDeleteAction = async function (executionContext) {
        var inputdata = Xrm.Utility.getPageContext().input.data;
        if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
            return false;
        }

        var review = executionContext.getAttribute('aia_relatedreview').getValue();
        var reviewId = review[0].id.replace(/[\{\}]*/g, "");

        var record = await Xrm.WebApi.retrieveRecord("aia_aia_crm_review", reviewId, "?$select=aia_reviewstatus");
        var reviewStatus = record.aia_reviewstatus;

        if (reviewStatus != CRMSdk.Status.Closed) {
            return true;
        }
        else {
            return false;
        }
    }
    //#endregion

    //#region code about action subgrid
    this.AddAction = function (executionContext) {
        let reviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        let reviewName = Xrm.Page.data.entity.getEntityReference().name;
        let entityName = Xrm.Page.data.entity.getEntityReference().entityType;

        if (reviewId == "") {
            executionContext.ui.setFormNotification("Please save the review at first.", "INFO", "AddAction");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("AddAction");
            }, 5000)
        }
        else {
            var pageInput = {
                pageType: "entityrecord",
                entityName: "aia_aia_crm_action",
                data: { "reviewId": reviewId, "reviewName": reviewName, "entityName": entityName }
            };

            var navigationOptions = {
                target: 2,
                height: { value: 80, unit: "%" },
                width: { value: 70, unit: "%" },
                position: 1
            };

            Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
                function success(result) {
                    // Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                    //     function success(actions) {
                    //         countofActions = actions.entities.length;
                    //         // update the record
                    //         var data = {
                    //             "aia_countofactions": String(countofActions)
                    //         }

                    //         // update the record
                    //         Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                    //             console.log("success", countofActions);
                    //         }, function (error) {
                    //             console.log("error", error.message);
                    //         });

                    //         //initial target close date
                    //         var targetCloseDate = executionContext.getAttribute('aia_targetclosedate').getValue();
                    //         var actualCloseDate = executionContext.getAttribute('aia_actualcloseddate').getValue();
                    //         if (reviewId != "") {
                    //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_targetclosedate&$orderby=aia_targetclosedate desc&$top=2").then(
                    //                 function success(actions) {
                    //                     console.log("actions", actions);
                    //                     if (actions.entities.length > 0) {
                    //                         var tdate = new Date(actions.entities[0].aia_targetclosedate);
                    //                         if (targetCloseDate == null || (targetCloseDate != null && new Date(targetCloseDate) < tdate)) {
                    //                             executionContext.getAttribute('aia_targetclosedate').setValue(tdate);
                    //                         }
                    //                     }
                    //                 },
                    //                 function (error) {
                    //                     console.log(error.message);
                    //                 }
                    //             );
                    //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_actualcloseddate&$orderby=aia_actualcloseddate desc&$top=2").then(
                    //                 function success(actions) {
                    //                     console.log("actions", actions);
                    //                     if (actions.entities.length > 0) {
                    //                         var tdate = new Date(actions.entities[0].aia_actualcloseddate);
                    //                         if (actualCloseDate == null || (actualCloseDate != null && new Date(actualCloseDate) < tdate)) {
                    //                             executionContext.getAttribute('aia_actualcloseddate').setValue(tdate);
                    //                         }
                    //                     }
                    //                 },
                    //                 function (error) {
                    //                     console.log(error.message);
                    //                 }
                    //             );
                    //         }
                    //     },
                    //     function (error) {
                    //         console.log(error.message);
                    //     }
                    // );
                    var subgrid = executionContext.getControl("tab_action_subgrid");
                    subgrid.refresh();
                    executionContext.getControl("WebResource_journeybar").getContentWindow().then(r => r.location.reload());
                },
                function error() {
                }
            );
        }
    }

    this.EditAction = function (executionContext) {
        const selectedRows = executionContext.getControl("tab_action_subgrid").getGrid().getSelectedRows().getAll();
        let reviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();

        if (selectedRows.length != 1) {
            executionContext.ui.setFormNotification("Please select an item for editing", "INFO", "EditAction");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("EditAction");
            }, 5000);
            return;
        }

        var selectedId = selectedRows[0]._entityId.guid;;

        var pageInput = {
            pageType: "entityrecord",
            entityName: "aia_aia_crm_action",
            entityId: selectedId
        };

        var navigationOptions = {
            target: 2,
            height: { value: 80, unit: "%" },
            width: { value: 70, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function success(result) {
                // Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,_aia_actionowner_value,aia_aia_crm_actionid&$orderby=createdon desc").then(
                //     function success(actions) {
                //         countofActions = actions.entities.length;
                //         // update the record
                //         var data = {
                //             "aia_countofactions": String(countofActions)
                //         }

                //         // update the record
                //         Xrm.WebApi.updateRecord("aia_aia_crm_review", reviewId, data).then(function success(result) {
                //             console.log("success", countofActions);
                //         }, function (error) {
                //             console.log("error", error.message);
                //         });

                //         //initial target close date
                //         var targetCloseDate = executionContext.getAttribute('aia_targetclosedate').getValue();
                //         var actualCloseDate = executionContext.getAttribute('aia_actualcloseddate').getValue();
                //         if (reviewId != "") {
                //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_targetclosedate&$orderby=aia_targetclosedate desc&$top=2").then(
                //                 function success(actions) {
                //                     console.log("actions", actions);
                //                     if (actions.entities.length > 0) {
                //                         var tdate = new Date(actions.entities[0].aia_targetclosedate);
                //                         if (targetCloseDate == null || (targetCloseDate != null && new Date(targetCloseDate) < tdate)) {
                //                             executionContext.getAttribute('aia_targetclosedate').setValue(tdate);
                //                         }
                //                     }
                //                 },
                //                 function (error) {
                //                     console.log(error.message);
                //                 }
                //             );
                //             Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + reviewId + "'&$select=aia_name,aia_actualcloseddate&$orderby=aia_actualcloseddate desc&$top=2").then(
                //                 function success(actions) {
                //                     console.log("actions", actions);
                //                     if (actions.entities.length > 0) {
                //                         var tdate = new Date(actions.entities[0].aia_actualcloseddate);
                //                         if (actualCloseDate == null || (actualCloseDate != null && new Date(actualCloseDate) < tdate)) {
                //                             executionContext.getAttribute('aia_actualcloseddate').setValue(tdate);
                //                         }
                //                     }
                //                 },
                //                 function (error) {
                //                     console.log(error.message);
                //                 }
                //             );
                //         }
                //     },
                //     function (error) {
                //         console.log(error.message);
                //     }
                // );
                var subgrid = executionContext.getControl("tab_action_subgrid");
                subgrid.refresh();
                executionContext.getControl("WebResource_journeybar").getContentWindow().then(r => r.location.reload());
            },
            function error() {
            }
        );
    }

    this.ViewAction = function (executionContext) {
        const selectedRows = executionContext.getControl("tab_action_subgrid").getGrid().getSelectedRows().getAll();

        if (selectedRows.length != 1) {
            executionContext.ui.setFormNotification("Please select an item for editing", "INFO", "EditAction");
            window.setTimeout(function () {
                executionContext.ui.clearFormNotification("EditAction");
            }, 5000);
            return;
        }

        var selectedId = selectedRows[0]._entityId.guid;;

        var pageInput = {
            pageType: "entityrecord",
            entityName: "aia_aia_crm_action",
            entityId: selectedId,
            data: { "view": true }
        };

        var navigationOptions = {
            target: 2,
            height: { value: 80, unit: "%" },
            width: { value: 70, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function success(result) {
                var subgrid = executionContext.getControl("tab_action_subgrid");
                subgrid.refresh();
            },
            function error() {
            }
        );
    }

    this.EnableAddAction = function (executionContext) {
        var review = executionContext.getAttribute("aia_reviewstatus").getValue();
        var returnvalue = false;

        if (review != CRMSdk.Status.Closed) {
            returnvalue = true;
        }

        return returnvalue;
    }

    this.EnableEditAction = function (executionContext, records) {
        var review = executionContext.getAttribute("aia_reviewstatus").getValue();
        var returnvalue = false;

        if (review != CRMSdk.Status.Closed) {
            returnvalue = true;
        }

        return returnvalue;
    }
    //#endregion

    //#region code about view include review/issue/action
    this.ExportReview = function () {
        var pageInput = {
            pageType: "webresource",
            webresourceName: "aia_aia_crm_reviewExport"
        };

        var navigationOptions = {
            target: 2,
            height: { value: 80, unit: "%" },
            width: { value: 70, unit: "%" },
            position: 1
        };

        Xrm.Navigation.navigateTo(pageInput, navigationOptions).then(
            function success(result) {
            },
            function error() {
            }
        );
    }

    this.ExportIssue = function () {
        Xrm.WebApi.retrieveMultipleRecords('aia_aia_crm_issue').then(res => {
            var ExcelRows = [];
            ExcelRows = res.entities.map(
                element => {
                    return {
                        issuestatus: element["aia_issuestatus@OData.Community.Display.V1.FormattedValue"],
                        aia_issuetitle: element.aia_issuetitle,
                        aia_name: element.aia_name,
                        aia_relatedreview: element["_aia_relatedreview_value@OData.Community.Display.V1.FormattedValue"],
                        aia_description: element.aia_description ? element.aia_description : null,
                        modifiedon: element["modifiedon@OData.Community.Display.V1.FormattedValue"],
                        createdon: element["createdon@OData.Community.Display.V1.FormattedValue"]
                    }
                }
            )
            const sheetName = "Sheet1";
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(ExcelRows);
            XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
            XLSX.writeFile(workbook, "Report.xlsx");
        });
    }

    this.ExportAction = function () {
        Xrm.WebApi.retrieveMultipleRecords('aia_aia_crm_action', `?$expand=aia_RelatedReview`).then(res => {
            var ExcelRows = [];
            ExcelRows = res.entities.map(
                element => {
                    return {
                        aia_actionstatus: element["aia_actionstatus@OData.Community.Display.V1.FormattedValue"],
                        aia_actiontitle: element.aia_actiontitle,
                        aia_name: element.aia_name,
                        aia_relatedreview: element["_aia_relatedreview_value@OData.Community.Display.V1.FormattedValue"],
                        aia_description: element.aia_description ? element.aia_description : null,
                        modifiedon: element["modifiedon@OData.Community.Display.V1.FormattedValue"],
                        createdon: element["createdon@OData.Community.Display.V1.FormattedValue"],
                        aia_relatedissue: element["_aia_relatedissue_value@OData.Community.Display.V1.FormattedValue"]
                    }
                }
            )

            const sheetName = "Sheet1";
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(ExcelRows);
            XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
            XLSX.writeFile(workbook, "Action.xlsx");
        });
    }

    this.ReopenReviewInView = function (executionContext, chooseItems) {
        var confirmStrings = {
            text: CRMSdk.ReopenReviewsMesg,
            title: CRMSdk.ReopenReviewTitle
        };
        var confirmOptions = {
            height: 150,
            width: 450
        };
        var confirmStringsError = {};
        // const selectedRows = executionContext.getGrid().getSelectedRows().getAll();
        // console.log(selectedRows, "selectedRows");
        console.log(chooseItems, "chooseItems");
        let allItems = [];
        let haveOpen = false;
        const PromiseArr = []
        chooseItems.map(x => {
            PromiseArr.push(window.parent.Xrm.WebApi.retrieveMultipleRecords('aia_aia_crm_review').then(res => {

                let item = res.entities.find(x1 => x1.aia_aia_crm_reviewid === x.Id)
                console.log(item, "item");
                if (item["aia_reviewstatus@OData.Community.Display.V1.FormattedValue"] != "Closed") {

                    haveOpen = true;
                }
                allItems.push(item);

            }))


        });
        Promise.all(PromiseArr).then(res => {
            {
                console.log(res);
                console.log('complete');
                if (haveOpen) {
                    confirmStringsError = {
                        errorCode: 404,
                        message: "The status of the reviews you selected is Open and cannot be reopened, please select again."
                    }
                    window.parent.Xrm.Navigation.openErrorDialog(confirmStringsError).then(
                        function (success) {
                            if (success.confirmed)
                                console.log("Dialog closed using OK button.");
                            else
                                console.log("Dialog closed using Cancel button or X.");
                        }
                    )
                } else {
                    window.parent.Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                        function (success) {
                            if (success.confirmed) {
                                Xrm.Utility.showProgressIndicator();
                                var data = {
                                    "aia_reviewstatus": CRMSdk.Status.InProgress,
                                    "aia_iscloseed": false
                                }
                                allItems.map(x => {

                                    Xrm.WebApi.updateRecord("aia_aia_crm_review", x.aia_aia_crm_reviewid, data).then(function success(result) {
                                        Xrm.Page.data.refresh();

                                        Xrm.Page.ui.setFormNotification(CRMSdk.ReopenedReviewsMesg, "INFO", "ReopenReview");
                                        window.setTimeout(function () {
                                            Xrm.Page.ui.clearFormNotification("ReopenReview");
                                        }, 5000);
                                        Xrm.Utility.closeProgressIndicator();
                                        // perform operations on record update
                                    }, function (error) {
                                        console.log("error", error.message);
                                        // handle error conditions
                                    });
                                });

                                // need to get selected items and loop logic here
                                // update the record

                            } else
                                console.log("Dialog closed using Cancel button or X.");
                        });


                }

            }
        })
    }
    //#endregion

    this.getName = function (Category, func) {
        Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_idcache", "?$filter=aia_name eq '" + Category + "'&$select=aia_name,aia_id").then(
            function success(caches) {
                var cacheGuid = caches.entities[0].aia_aia_crm_idcacheid;
                var cacheId = caches.entities[0].aia_id;
                var newCacheId = (Number(cacheId) + 1).toString();

                var data = {
                    aia_id: newCacheId
                };

                Xrm.WebApi.updateRecord("aia_aia_crm_idcache", cacheGuid, data).then(function success(newCaches) {
                    var newId = Category.substring(0, 1) + newCacheId.padStart(5, '0');
                    func(newId);
                    return newId;
                }, function (error) {
                    console.log("error", error.message);
                });
            },
            function (error) {
                console.log(error.message);
            }
        );
    }

    //#region public function
    this.generateNum = function (num) {
        var prefixId = num.substring(0, 1);
        var suffixId = num.substring(6, 1);
        var temp = (Number(suffixId) + 1).toString();
        temp = prefixId + temp.padStart(5, '0');
        console.log(temp);
        return temp;
    }

    this.getTeamJSON = function (TeamIds) {
        var permissionStr = `{
            "ActionPermission": {
                "Principal": {
                    "teamid": "{0}",
                    "@odata.type": "Microsoft.Dynamics.CRM.team"
                },
                "AccessMask": "{1}"
            }
        }`;

        var teamJson = [];
        TeamIds.forEach(function (item) {
            switch (item.Type) {
                case "BUInitial":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess,WriteAccess,AppendAccess,AppendToAccess"))
                    break;
                case "BUVisitor":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess"))
                    break;
                case "BUAdmin":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess,WriteAccess,AppendAccess,AppendToAccess,DeleteAccess"))
                    break;
                case "GroupInitial":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess,WriteAccess,AppendAccess,AppendToAccess"))
                    break;
                case "GroupVisitor":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess"))
                    break;
                case "Admin":
                    teamJson.push(permissionStr.format(item.Id, "ReadAccess,WriteAccess,AppendAccess,AppendToAccess,DeleteAccess"))
                    break;
            }
        })
        return "[" + teamJson.join(',') + "]";
    }

    this.getReviewJsonPermission = function (RecordColl, TeamIds) {
        var permissionStr = `{
            "RecordId": "aia_aia_crm_{0}",
            "ActionPermission": {
                "Principal": {
                    "{1}": "{2}",
                    "@odata.type": "Microsoft.Dynamics.CRM.{3}"
                },
                "AccessMask": "{4}"
            }
        }`;

        var permissionJson = [];

        RecordColl.forEach(function (record) {
            TeamIds.forEach(function (item) {
                switch (item.Type) {
                    case "BUInitial":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess,WriteAccess,AppendAccess,AppendToAccess"))
                        break;
                    case "BUVisitor":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess"))
                        break;
                    case "BUAdmin":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess,WriteAccess,AppendAccess,AppendToAccess,DeleteAccess"))
                        break;
                    case "GroupInitial":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess,WriteAccess,AppendAccess,AppendToAccess"))
                        break;
                    case "GroupVisitor":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess"))
                        break;
                    case "Admin":
                        permissionJson.push(permissionStr.format(record.recordType + "(" + record.recordId + ")", "teamid", item.Id, "team", "ReadAccess,WriteAccess,AppendAccess,AppendToAccess,DeleteAccess"))
                        break;
                }
            })
        })

        return permissionJson;
    }

    this.InsertToAIA_CRM_IARecord = function (ReviewId, Table, ItemId, Action) {
        var data =
        {
            "aia_name": "AIA_CRM_IARecord",
            "aia_reviewguid": ReviewId,
            "aia_table": Table,
            "aia_itemid": ItemId,
            "aia_action": Action
        }

        // create account record
        Xrm.WebApi.createRecord("aia_aia_crm_iarecord", data).then(
            function success(result) {
                console.log("aia_aia_crm_iarecord created with ID: " + result.id);
            },
            function (error) {
                console.log(error.message);
            }
        );
    }
    //#endregion
}).call(CRMRibbon)
