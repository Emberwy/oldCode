var CRMSdk = window.CRMSdk || {};
window.parent.CRMSdk = window.CRMSdk || {};

(function () {
    console.log("CRMSdk");

    //#region code about variables
    this.ReviewViews = {
        defaultView: "c0b024f1-fa12-4e78-996a-a63436f3c549",
        notstartView: "23e873c5-1a2d-ee11-9966-6045bd57c826",
        inprogressView: "b8ae1e81-212d-ee11-9965-000d3a82ce7d",
        completedView: "0889bda0-212d-ee11-9965-000d3a82ce7d",
        closedView: "72e32bcf-503b-ee11-bdf5-002248ecf212",
        RSINotStart: "9756bed7-af94-ee11-be37-000d3a82cc33",
        RSIInprogress: "038e7734-b194-ee11-be37-000d3a82ce7d",
        RSICompleted: "2735339e-c394-ee11-be37-000d3a82ce7d",
        RSIClosed: "86918413-c494-ee11-be37-000d3a82ce7d",
        RSIHaveOpenIssue: "cf2a1f3c-c794-ee11-be37-002248ecf78c",
        RSIHaveIssue: "5a2b66a7-c794-ee11-be37-6045bd57c826",
        RSIHaveOpenAction: "69aa63cb-c994-ee11-be37-000d3a82cc33"
    }

    this.IssueViews = {
        defaultView: "001e6b28-9989-4921-9a9c-0959eca01c5c",
        openView: "afbc1ea1-192d-ee11-9966-6045bd57c826",
        closedView: "454af2d2-192d-ee11-9965-000d3a82ce7d"
    }

    this.GroupRoles = {
        InitalNormal: "ba8f90a9-286f-ee11-9ae7-000d3ac7111c",
        InitalConfidential: "b88f90a9-286f-ee11-9ae7-000d3ac7111c",
        VisitorNormal: "47d3fa88-9e6c-ee11-9ae7-000d3a85c697",
        VisitorConfidential: "45d3fa88-9e6c-ee11-9ae7-000d3a85c697"

    }
    this.ActionViews = {
        defaultView: "260f2874-9e1c-4a95-8856-bbaf9218485d",
        openView: "b58436cd-162d-ee11-9965-000d3a82cc33",
        closedView: "128cfd1a-172d-ee11-9965-000d3a82cc33"
    }

    this.Status = {
        NotStarted: 589450000,
        InProgress: 589450001,
        Completed: 589450002,
        Closed: 589450003
    }
    this.reviewcategory = {
        category: 589450000,
        RSI: 589450001

    }
    this.Manager = {
        BUAdmin: "53d6875a-c56c-ee11-9ae7-000d3a82ce7d",
        SystemAdmin: "907c50e4-4042-ee11-bdf4-000d3a82cc33",
        UserAdmin: "84c9d00d-4142-ee11-bdf4-000d3a82c8b1"


    }
    this.Confidential = {
        InitiatorConfidential: "13b5cf98-4a42-ee11-bdf4-002248ecf212",
        visitorConfidential: "eb2906c6-4a42-ee11-bdf4-002248ecf212"

    }
    this.Normal = {
        InitiatorNormal: "ba14487f-4a42-ee11-bdf4-002248ecf212",
        visitorNormal: "6e2cffac-4a42-ee11-bdf4-002248ecf212"

    }

    this.SubStatus = {
        Open: 589450000,
        Closed: 589450001
    }
    this.closureStatus = {
        Open: 589450000,
        Closed: 589450001
    }
    this.applicablepolicestandard = {
        Applicable: 589450000
    }
    this.ComplianceProgramme = {
        'Compliance Programme': 589450000
    }
    this.l2l3risktype = {
        'L2/L3 Risk Type': 589450000
    }

    this.AttachmentType = {
        Review: 589450000,
        Issue: 589450001,
        Action: 589450002,
        ClosureofReview: 589450003
    }

    this.CRMBusinessUnit = {
        GroupOffice: 589450000,
        Australia: 589450001,
        Bermuda: 589450002,
        Brunei: 589450003,
        Cambodia: 589450004,
        China: 589450005,
        HongKongAIAInternational: 589450006,
        HongKongBlueCross: 589450007,
        HongKongConsumerServices: 589450008,
        HongKongEverestLife: 589450009,
        HongKongInvestmentManagement: 589450010,
        HongKongTrustee: 589450011,
        MacauAIAInternational: 589450012,
        India: 589450013,
        Indonesia: 589450014,
        Korea: 589450015,
        MalaysiaAIABerhad: 589450016,
        MalaysiaGeneralBerhad: 589450017,
        MalaysiaAPAM: 589450018,
        MalaysiaTakaful: 589450019,
        MalaysiaSharedService: 589450020,
        Myanmar: 589450021,
        NewZealand: 589450022,
        PhilippinesInvestmentManagement: 589450023,
        PhilippinesPhilamLife: 589450024,
        PhilippinesBPI: 589450025,
        Singapore: 589450026,
        SingaporeInvestmentManagement: 589450027,
        SingaporeFinancialAdvisers: 589450028,
        SriLanka: 589450029,
        Taiwan: 589450030,
        Thailand: 589450031,
        Vietnam: 589450032
    }

    this.RecordStatus = {
        Draft: 589450000,
        Published: 589450001
    }

    this.attchmentSizeLimitation = 1024 * 1024 * 20;
    this.attchmentSizeLimitationMesg = "The system don't allow to upload attachment more than 20MB.";
    this.attchmentCountLimitation = 10;
    this.attchmentCountLimitationMesg = "The system don't allow to upload attachment more than 10.";
    this.attchmentDeleteTitle = "Delete confirmation";
    this.attchmentDeleteMesg = "Are you sure you want to delete this file?";
    this.attchmentDeletedMesg = "The file was deleted.";
    this.saveReviewDateErrorMesg = "Review End Date must more than Start Date.";
    this.saveReviewStatusErrorMesg = "Please ensure that \"Findings/Issues/Action Status\" is set to \"Closed\" and that all issues and actions are also marked as \"Closed\" before updating the Review Status as \"Closed\". ";
    this.saveReviewMesg = "Please save this review first";
    this.SaveReviewTitle = "Save confirmation";
    this.SaveReviewMesg = "Are you sure you want to save this review?";
    this.SavedReviewMesg = "The review was saved.";
    this.SubmitReviewTitle = "Submit confirmation";
    this.SubmitReviewMesg = "Are you sure you want to submit this review?";
    this.SubmitedReviewMesg = "The review was submitted.";
    this.UpdateReviewTitle = "Save confirmation";
    this.UpdateReviewMesg = "Are you sure you want to save this review?";
    this.UpdatedReviewMesg = "The review was updated.";
    this.CloseReviewTitle = "Close confirmation";
    this.CloseReviewMesg = "Are you sure you want to close this review?";
    this.ClosedReviewMesg = "The review was closed.";
    this.ReopenReviewTitle = "Reopen confirmation";
    this.ReopenReviewMesg = "Are you sure you want to reopen this review?";
    this.ReopenedReviewMesg = "The review was reopened.";
    this.ReopenReviewsMesg = "Are you sure you want to reopen these reviews?";
    this.ReopenedReviewsMesg = "These reviews were reopened.";
    this.DeleteReviewTitle = "Delete confirmation";
    this.DeleteReviewMesg = "Are you sure you want to delete this review?";
    this.DeletedReviewMesg = "The review was deleted.";
    this.SaveIssueTitle = "Save confirmation";
    this.SaveIssueMesg = "Are you sure you want to save this issue?";
    this.SavedIssueMesg = "The issue was saved.";
    this.DeleteIssueTitle = "Delete confirmation";
    this.DeleteIssueMesg = "Are you sure you want to delete this issue?";
    this.DeletedIssueMesg = "The issue was deleted.";
    this.SaveActionTitle = "Save confirmation";
    this.SaveActionMesg = "Are you sure you want to save this action?";
    this.SavedActionMesg = "The action was saved.";
    this.DeleteActionTitle = "Delete confirmation";
    this.DeleteActionMesg = "Are you sure you want to delete this action?";
    this.DeletedActionMesg = "The action was deleted.";
    //#endregion

    this.preventAutoSave = function (executionContext) {
        var eventArgs = executionContext.getEventArgs();
        if (eventArgs.getSaveMode() == 70) {
            eventArgs.preventDefault();
        }

        if (eventArgs.getSaveMode() == 2) {
            Xrm.Page.ui.setFormNotification("Please click Save/Update button in the top or discard changes before leave current page.", "ERROR", "SaveAndClose");
            window.setTimeout(function () {
                Xrm.Page.ui.clearFormNotification("SaveAndClose");
            }, 5000);
            eventArgs.preventDefault();
        }
    }

    this.reviewOnLoad = function (executionContext) {
        var formContext = executionContext.getFormContext();
        let ReviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var reviewStatus = formContext.getAttribute('aia_reviewstatus').getValue();
        var currentUser = Xrm.Page.context.getUserId().replace(/[\{\}]*/g, "");
        var closeDate = formContext.getAttribute('aia_actualcloseddate').getValue();
        console.log(closeDate, "ActualClosed");
        //set Target Close Date
        if (ReviewId != "") {
            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + ReviewId + "'&$select=aia_name,aia_targetclosedate&$orderby=aia_targetclosedate desc&$top=2").then(
                function success(actions) {
                    console.log("actions", actions);
                    if (actions.entities.length > 0) {
                        formContext.getAttribute('aia_targetclosedate').setValue(new Date(actions.entities[0].aia_targetclosedate));
                    }
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }

        Xrm.WebApi.retrieveRecord("systemuser", currentUser, "?$select=internalemailaddress,fullname").then(

            function success(result) {
                console.log("Retrieved values: Name: " + result.internalemailaddress + ", Revenue: " + result.fullname);
                debugger;
                fetch(
                    `/api/data/v9.0/systemusers?$select=domainname&$expand=teammembership_association($select=teamid,name;$filter=startswith(name,'AIA CRM'))&$filter=domainname eq '${result.internalemailaddress}'`,
                    {
                        headers: {
                            "Content-Type": "application/json",
                            'Prefer': 'odata.include-annotations="*"'
                        }
                    }
                ).then(res => res.json()).then(res => {
                    console.log(res, "writeAble User");

                    var buControl = formContext.getControl('aia_businessunit');

                    if (res.value.length == 0) {
                        // remove all options in BU
                        var allOptions = buControl.getOptions();
                        for (var i = 0; i < allOptions.length; i++) {
                            buControl.removeOption(allOptions[i].value);
                        }

                    } else {
                        var teamIdColl = [];

                        res.value[0].teammembership_association.forEach(function (obj) {
                            teamIdColl.push(obj.teamid);
                        })

                        if (CRMSdk.checkReadOrWrite(teamIdColl, CRMTeamList.CRMTeam.GroupRead) && reviewStatus != this.Status.Closed) {
                            console.log("userCanRead");
                            formContext.getControl("aia_groupofficeissuessummary").setVisible(true);
                            formContext.getControl("aia_groupofficereportingsummary").setVisible(true);
                            formContext.getControl("aia_groupofficeissuessummary").setDisabled(true);
                            formContext.getControl("aia_groupofficereportingsummary").setDisabled(true);
                        } else if (CRMSdk.checkReadOrWrite(teamIdColl, CRMTeamList.CRMTeam.GroupWrite) && reviewStatus != this.Status.Closed) {
                            console.log("userCanWrite");
                            formContext.getControl("aia_groupofficeissuessummary").setVisible(true);
                            formContext.getControl("aia_groupofficereportingsummary").setVisible(true);
                            formContext.getControl("aia_groupofficeissuessummary").setDisabled(false);
                            formContext.getControl("aia_groupofficereportingsummary").setDisabled(false);
                        }
                        else if (reviewStatus != this.Status.Closed) {
                            formContext.getControl("aia_groupofficeissuessummary").setVisible(false);
                            formContext.getControl("aia_groupofficereportingsummary").setVisible(false);
                        }
                    }

                }).catch(err => {
                    console.error(err)
                })
            },
            function (error) {
                console.log(error.message);
            }
        );
        var actualCloseDate = formContext.getAttribute('aia_actualcloseddate').getValue();
        var findingStatus = formContext.getAttribute('aia_findingsstatus').getValue();

        if (findingStatus == this.SubStatus.Closed) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
        }
        else {

            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("none");
            formContext.getControl("aia_actualcloseddate").setVisible(true);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("none");
            formContext.getAttribute('aia_actualcloseddate').setValue(null);
            //  formContext.getControl("aia_actualcloseddate").setVisible(true);
        }


        if (reviewStatus == this.Status.NotStarted || reviewStatus == this.Status.InProgress || reviewStatus == this.Status.Completed) {
            //control BU permission
            Xrm.WebApi.retrieveRecord("systemuser", currentUser, "?$select=internalemailaddress,fullname").then(
                function success(result) {
                    console.log("Retrieved values: Name: " + result.internalemailaddress + ", Revenue: " + result.fullname);
                    debugger;
                    fetch(
                        `/api/data/v9.0/systemusers?$select=domainname&$expand=teammembership_association($select=teamid,name;$filter=startswith(name,'AIA CRM'))&$filter=domainname eq '${result.internalemailaddress}'`,
                        {
                            headers: {
                                "Content-Type": "application/json",
                                'Prefer': 'odata.include-annotations="*"'
                            }
                        }
                    ).then(res => res.json()).then(res => {


                        var buControl = formContext.getControl('aia_businessunit');

                        if (res.value.length == 0) {
                            // remove all options in BU
                            var allOptions = buControl.getOptions();
                            for (var i = 0; i < allOptions.length; i++) {
                                buControl.removeOption(allOptions[i].value);
                            }

                        } else {
                            var teamIdColl = [];
                            var selectedBU = "";
                            res.value[0].teammembership_association.forEach(function (obj) {
                                console.log(obj.name);
                                console.log(obj.teamid);
                                teamIdColl.push(obj.teamid);
                            })

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAGroup)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAGroup);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAGroup;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAHongKongMacau)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAHongKongMacau);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAHongKongMacau;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIASingapore)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIASingapore);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIASingapore;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAAustralia)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAAustralia);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAAustralia;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAChina)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAChina);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAChina;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIABrunei)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIABrunei);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIABrunei;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAKorea)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAKorea);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAKorea;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAMalaysia)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAMalaysia);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAMalaysia;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAPensionTrustee)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAPensionTrustee);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAPensionTrustee;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIASriLanka)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIASriLanka);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIASriLanka;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIATaiwan)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIATaiwan);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIATaiwan;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAThailand)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAThailand);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAThailand;
                            // }

                            // if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.AIAVietnam)) {
                            //     buControl.removeOption(CRMSdk.CRMBusinessUnit.AIAVietnam);
                            // } else {
                            //     selectedBU = CRMSdk.CRMBusinessUnit.AIAVietnam;
                            // }

                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.GroupOffice)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.GroupOffice); } else { selectedBU = CRMSdk.CRMBusinessUnit.GroupOffice; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Australia)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Australia); } else { selectedBU = CRMSdk.CRMBusinessUnit.Australia; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Bermuda)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Bermuda); } else { selectedBU = CRMSdk.CRMBusinessUnit.Bermuda; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Brunei)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Brunei); } else { selectedBU = CRMSdk.CRMBusinessUnit.Brunei; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Cambodia)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Cambodia); } else { selectedBU = CRMSdk.CRMBusinessUnit.Cambodia; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.China)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.China); } else { selectedBU = CRMSdk.CRMBusinessUnit.China; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongAIAInternational)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongAIAInternational); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongAIAInternational; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongBlueCross)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongBlueCross); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongBlueCross; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongConsumerServices)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongConsumerServices); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongConsumerServices; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongEverestLife)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongEverestLife); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongEverestLife; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongInvestmentManagement)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongInvestmentManagement); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongInvestmentManagement; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.HongKongTrustee)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.HongKongTrustee); } else { selectedBU = CRMSdk.CRMBusinessUnit.HongKongTrustee; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MacauAIAInternational)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MacauAIAInternational); } else { selectedBU = CRMSdk.CRMBusinessUnit.MacauAIAInternational; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.India)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.India); } else { selectedBU = CRMSdk.CRMBusinessUnit.India; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Indonesia)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Indonesia); } else { selectedBU = CRMSdk.CRMBusinessUnit.Indonesia; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Korea)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Korea); } else { selectedBU = CRMSdk.CRMBusinessUnit.Korea; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MalaysiaAIABerhad)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MalaysiaAIABerhad); } else { selectedBU = CRMSdk.CRMBusinessUnit.MalaysiaAIABerhad; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MalaysiaGeneralBerhad)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MalaysiaGeneralBerhad); } else { selectedBU = CRMSdk.CRMBusinessUnit.MalaysiaGeneralBerhad; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MalaysiaAPAM)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MalaysiaAPAM); } else { selectedBU = CRMSdk.CRMBusinessUnit.MalaysiaAPAM; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MalaysiaTakaful)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MalaysiaTakaful); } else { selectedBU = CRMSdk.CRMBusinessUnit.MalaysiaTakaful; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.MalaysiaSharedService)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.MalaysiaSharedService); } else { selectedBU = CRMSdk.CRMBusinessUnit.MalaysiaSharedService; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Myanmar)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Myanmar); } else { selectedBU = CRMSdk.CRMBusinessUnit.Myanmar; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.NewZealand)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.NewZealand); } else { selectedBU = CRMSdk.CRMBusinessUnit.NewZealand; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.PhilippinesInvestmentManagement)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.PhilippinesInvestmentManagement); } else { selectedBU = CRMSdk.CRMBusinessUnit.PhilippinesInvestmentManagement; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.PhilippinesPhilamLife)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.PhilippinesPhilamLife); } else { selectedBU = CRMSdk.CRMBusinessUnit.PhilippinesPhilamLife; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.PhilippinesBPI)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.PhilippinesBPI); } else { selectedBU = CRMSdk.CRMBusinessUnit.PhilippinesBPI; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Singapore)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Singapore); } else { selectedBU = CRMSdk.CRMBusinessUnit.Singapore; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.SingaporeInvestmentManagement)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.SingaporeInvestmentManagement); } else { selectedBU = CRMSdk.CRMBusinessUnit.SingaporeInvestmentManagement; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.SingaporeFinancialAdvisers)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.SingaporeFinancialAdvisers); } else { selectedBU = CRMSdk.CRMBusinessUnit.SingaporeFinancialAdvisers; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.SriLanka)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.SriLanka); } else { selectedBU = CRMSdk.CRMBusinessUnit.SriLanka; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Taiwan)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Taiwan); } else { selectedBU = CRMSdk.CRMBusinessUnit.Taiwan; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Thailand)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Thailand); } else { selectedBU = CRMSdk.CRMBusinessUnit.Thailand; }
                            if (!CRMSdk.checkExisted(teamIdColl, CRMTeamList.CRMTeam.Vietnam)) { buControl.removeOption(CRMSdk.CRMBusinessUnit.Vietnam); } else { selectedBU = CRMSdk.CRMBusinessUnit.Vietnam; }

                            if (ReviewId == "") {
                                buControl.getAttribute().setValue(selectedBU);

                                //add to hide Attachments
                                var hideBotton = window.top.document.getElementById("WebResource_review");
                                hideBotton.style.display = '';
                                hideBotton.style.display = 'none';

                            }

                            var currentBU = formContext.getAttribute('aia_businessunit').getValue();

                            // if (currentBU == CRMSdk.CRMBusinessUnit.AIAGroup) {
                            //     formContext.getControl("aia_groupofficereportingsummary").setDisabled(false);
                            // } else {
                            //     formContext.getControl("aia_groupofficereportingsummary").setDisabled(true);
                            // }

                            //initial Legal Entity and Name of Regulator by BU
                            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_bumappinglist", "?$filter=aia_businessunit eq '" + currentBU + "'&$select=aia_legalentity,aia_nameofregulator").then(
                                function success(records) {
                                    var control1 = formContext.getControl('aia_legalentity');
                                    var control2 = formContext.getControl('aia_nameofregulator1');

                                    var options1 = control1.getOptions();
                                    var options2 = control2.getOptions();

                                    if (records.entities.length > 0) {
                                        var var1 = records.entities[0].aia_legalentity;
                                        var var2 = records.entities[0].aia_nameofregulator;
                                        console.log("var1", var1);
                                        console.log("var2", var2);

                                        for (var i = 0; i < options1.length; i++) {
                                            if (var1.indexOf(options1[i].value) < 0)
                                                control1.removeOption(options1[i].value);
                                        }

                                        for (var i = 0; i < options2.length; i++) {
                                            if (var2.indexOf(options2[i].value) < 0)
                                                control2.removeOption(options2[i].value);
                                        }

                                    } else {
                                        for (var i = 0; i < options1.length; i++) {
                                            control1.removeOption(options1[i].value);
                                        }

                                        for (var i = 0; i < options2.length; i++) {
                                            control2.removeOption(options2[i].value);
                                        }
                                    }
                                },
                                function (error) {
                                    console.log(error.message);
                                }
                            );
                        }
                    }).catch(err => {
                        console.error(err)
                    })
                },
                function (error) {
                    console.log(error.message);
                }
            );
        }

        //589450000 Non-compliance with regulatory requirement
        if (reviewStatus == this.Status.NotStarted) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            // formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("none");
        }
        else if (reviewStatus == this.Status.InProgress) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            // formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        } else if (reviewStatus == this.Status.Completed || reviewStatus == this.Status.Closed) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("required");
            formContext.getAttribute("aia_function").setRequiredLevel("required");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("required");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("required");
            // formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        } else {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            // formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        }

        //initial display logic about Regulatory Review Details
        var reviewcategoryStatus = formContext.getAttribute('aia_reviewcategory').getValue();
        var section = formContext.ui.tabs.get("tab_review").sections.get("review_tab_section_regulatoryreviewdetails");

        if (reviewcategoryStatus == 589450001) {
            section.setVisible(true);
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("required");
        } else {
            section.setVisible(false);
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
        }

        if (ReviewId != "" && reviewStatus == this.Status.Closed) {
            // formContext.getControl("aia_groupofficeissuessummary").setDisabled(true);
            // formContext.getControl("aia_groupofficereportingsummary").setDisabled(true);
            formContext.ui.tabs.forEach(function (tab) {
                tab.sections.forEach(function (section) {
                    section.controls.forEach(function (control) {
                        control.setDisabled(true);
                    })
                });
            });

            console.log("aia_groupofficereportingsummary disable...");
            formContext.getControl('aia_groupofficeissuessummary').setDisabled(true);
            formContext.getControl('aia_groupofficereportingsummary').setDisabled(true);
        }
    }

    // this.checkExisted = function (arr, obj) {
    //     if (arr.findIndex(item => item == obj.InitalConfidential) >= 0 || arr.findIndex(item => item == obj.InitalNormal) >= 0) {
    //         return true;
    //     } else {
    //         return false;
    //     }
    // }

    this.checkExisted = function (arr, obj) {
        var codeList = Object.values(obj);
        for (var i in codeList) {
            if (arr.findIndex(item => item == codeList[i]) >= 0) {
                return true;
            }
        }

        return false;

    }
    this.checkReadOrWrite = function (arr, obj) {
        let set = new Set(arr);
        for (let key in obj) {
            if (set.has(obj[key])) {
                return true;
            }
        }
        return false;
    }

    this.reviewCategoryOnChanged = function (executionContext) {
        var formContext = executionContext.getFormContext();

        //Regulatory and Supervisory Inspection: 589450001
        var reviewcategoryStatus = formContext.getAttribute('aia_reviewcategory').getValue();
        var section = formContext.ui.tabs.get("tab_review").sections.get("review_tab_section_regulatoryreviewdetails");

        if (reviewcategoryStatus == "589450001") {
            section.setVisible(true);
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("required");
        } else {
            section.setVisible(false);
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
        }
    }

    this.ActionClosedOnChange = function (executionContext) {
        var formContext = executionContext.getFormContext();
        var ActionStatus = formContext.getAttribute('aia_actionstatus').getValue();
        if (ActionStatus == this.closureStatus.Closed) {
            formContext.getControl("aia_actualcloseddate").setVisible(true);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("required");

        }
        else {
            formContext.getControl("aia_actualcloseddate").setVisible(false);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("none");
        }


    }
    this.reviewFindingClosedOnChange = function (executionContext) {
        var formContext = executionContext.getFormContext();
        let ReviewId = Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var findingStatus = formContext.getAttribute('aia_findingsstatus').getValue();
        var actualCloseDate = formContext.getAttribute('aia_actualcloseddate').getValue();
        console.log(findingStatus, "findingStatus");
        if (findingStatus == this.closureStatus.Closed) {
            Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_action", "?$filter=_aia_relatedreview_value eq '" + ReviewId + "'&$select=aia_name,aia_actualcloseddate&$orderby=aia_actualcloseddate desc&$top=2").then(

                function success(actions) {

                    console.log("actions", actions);

                    if (actions.entities.length > 0 && findingStatus == CRMSdk.SubStatus.Closed) {

                        const tdate = new Date(actions.entities[0].aia_actualcloseddate);

                        if (actions.entities[0].aia_actualcloseddate != null && (actualCloseDate == null || (actualCloseDate != null && new Date(actualCloseDate) < tdate))) {

                            formContext.getAttribute('aia_actualcloseddate').setValue(tdate);
                        }

                    }

                },

                function (error) {

                    console.log(error.message);

                }

            );
            formContext.getControl("aia_actualcloseddate").setVisible(true);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("required");

        }
        else {
            formContext.getControl("aia_actualcloseddate").setVisible(true);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("none");
            formContext.getAttribute('aia_actualcloseddate').setValue(null);
        }
    }
    this.reviewStatusOnChanged = function (executionContext) {
        var formContext = executionContext.getFormContext();
        var reviewStatus = formContext.getAttribute('aia_reviewstatus').getValue();

        //589450000 Non-compliance with regulatory requirement
        if (reviewStatus == this.Status.NotStarted) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("none");
        }
        else if (reviewStatus == this.Status.InProgress) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        } else if (reviewStatus == this.Status.Completed || reviewStatus == this.Status.Closed) {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("required");
            formContext.getAttribute("aia_function").setRequiredLevel("required");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("required");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("required");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("required");
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        } else {
            formContext.getAttribute("aia_reviewtitle").setRequiredLevel("required");
            formContext.getAttribute("aia_legalentity").setRequiredLevel("none");
            formContext.getAttribute("aia_function").setRequiredLevel("none");
            formContext.getAttribute("aia_complianceprogramme").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewstartdate").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewenddate").setRequiredLevel("none");
            formContext.getAttribute("aia_briefdescription").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofregulator1").setRequiredLevel("none");
            formContext.getAttribute("aia_reviewcategory").setRequiredLevel("required");
        }

    }

    this.businessUnitOnChanged = function (executionContext) {
        var formContext = executionContext.getFormContext();
        var currentBU = formContext.getAttribute('aia_businessunit').getValue();

        // if (currentBU == CRMSdk.CRMBusinessUnit.AIAGroup) {
        //     formContext.getControl("aia_groupofficereportingsummary").setDisabled(false);
        // } else {
        //     formContext.getControl("aia_groupofficereportingsummary").setDisabled(true);
        // }

        Xrm.WebApi.retrieveMultipleRecords("aia_aia_crm_bumappinglist", "?$filter=aia_businessunit eq '" + currentBU + "'&$select=aia_legalentity,aia_nameofregulator").then(
            function success(records) {
                var control1 = formContext.getControl('aia_legalentity');
                var control2 = formContext.getControl('aia_nameofregulator1');

                var attr1 = formContext.getAttribute('aia_legalentity');
                var attr2 = formContext.getAttribute('aia_nameofregulator1');

                var options1 = attr1.getOptions();
                var options2 = attr2.getOptions();

                if (records.entities.length > 0) {
                    var var1 = records.entities[0].aia_legalentity;
                    var var2 = records.entities[0].aia_nameofregulator;

                    control1.clearOptions();
                    control2.clearOptions();

                    for (var i = 0; i < options1.length; i++) {
                        if (var1.indexOf(options1[i].value) >= 0)
                            control1.addOption(options1[i]);
                    }

                    for (var i = 0; i < options2.length; i++) {
                        if (var2.indexOf(options2[i].value) >= 0)
                            control2.addOption(options2[i]);
                    }
                } else {
                    control1.clearOptions();
                    control2.clearOptions();
                }
            },
            function (error) {
                console.log(error.message);
            }
        );
    }

    this.newIssueOnLoad = function (executionContext) {
        let issueId = window.parent.Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        formContext = executionContext.getFormContext();
        var inputdata = Xrm.Utility.getPageContext().input.data;

        if (issueId == "") {


            let lookupData = [
                {
                    "entityType": inputdata.entityName,
                    "id": inputdata.reviewId,
                    "name": inputdata.reviewName
                }
            ]

            formContext.getAttribute('aia_relatedreview').setValue(lookupData);
        } else {
            var hideBotton = window.top.document.getElementById("WebResource_new_1");
            if (hideBotton != null) {
                hideBotton.style.opacity = 1;
            }

            if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
                formContext.ui.tabs.forEach(function (tab) {
                    tab.sections.forEach(function (section) {
                        section.controls.forEach(function (control) {
                            control.setDisabled(true);
                        })
                    });
                });
            }
        }

        formContext.getControl("aia_relatedreview").setDisabled(true);
        var natureValue = formContext.getAttribute('aia_nature').getValue();

        //589450000 Non-compliance with regulatory requirement
        if (natureValue == "589450000") {
            formContext.getControl("aia_nameoflaw").setVisible(true);
            formContext.getControl("aia_nameofpolicystandard").setVisible(false);

            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getControl("aia_descriptionofrequirement").setVisible(true);
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("required");
        }
        else if (natureValue == "589450001") {
            formContext.getControl("aia_nameoflaw").setVisible(false);
            formContext.getControl("aia_nameofpolicystandard").setVisible(true);
            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getControl("aia_descriptionofrequirement").setVisible(true);
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("required");
        }
        else {
            formContext.getControl("aia_nameoflaw").setVisible(false);
            formContext.getControl("aia_nameofpolicystandard").setVisible(false);
            formContext.getControl("aia_descriptionofrequirement").setVisible(false);
            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("none");
        }


        var issueStatus = formContext.getAttribute('aia_issuestatus').getValue();
        if (issueId != "" && issueStatus == "589450001") {
            formContext.ui.tabs.forEach(function (tab) {
                tab.sections.forEach(function (section) {
                    section.controls.forEach(function (control) {
                        control.setDisabled(true);
                    })
                });
            });
        }


        localStorage.setItem("IssueStatus", issueStatus);
    }

    this.newIssueNatureOnChanged = function (executionContext) {
        var formContext = executionContext.getFormContext();
        var natureValue = formContext.getAttribute('aia_nature').getValue();

        //589450000 Non-compliance with regulatory requirement
        if (natureValue == "589450000") {
            formContext.getControl("aia_nameoflaw").setVisible(true);
            formContext.getControl("aia_nameofpolicystandard").setVisible(false);

            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getControl("aia_descriptionofrequirement").setVisible(true);
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("required");
        }
        else if (natureValue == "589450001") {
            formContext.getControl("aia_nameoflaw").setVisible(false);
            formContext.getControl("aia_nameofpolicystandard").setVisible(true);
            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getControl("aia_descriptionofrequirement").setVisible(true);
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("required");
        }
        else {
            formContext.getControl("aia_nameoflaw").setVisible(false);
            formContext.getControl("aia_nameofpolicystandard").setVisible(false);
            formContext.getControl("aia_descriptionofrequirement").setVisible(false);
            formContext.getAttribute("aia_nameoflaw").setRequiredLevel("none");
            formContext.getAttribute("aia_nameofpolicystandard").setRequiredLevel("none");
            formContext.getAttribute("aia_descriptionofrequirement").setRequiredLevel("none");
        }
    }

    this.newActionOnLoad = function (executionContext) {
        let actionId = window.parent.Xrm.Page.data.entity.getId().replace(/[\{\}]*/g, "").toLowerCase();
        var inputdata = Xrm.Utility.getPageContext().input.data;
        formContext = executionContext.getFormContext();

        // var actionOwner = formContext.getAttribute('aia_actionowner').getValue();
        // var lastActionOwner = formContext.getAttribute('aia_lastactionowner').getValue();
        // if (actionOwner != "" && actionOwner != lastActionOwner) {
        //     formContext.getAttribute('aia_lastactionowner').setValue(actionOwner);
        // }
        var ActionStatus = formContext.getAttribute('aia_actionstatus').getValue();
        if (ActionStatus == this.closureStatus.Closed) {
            formContext.getControl("aia_actualcloseddate").setVisible(true);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("required");

        }
        else {
            formContext.getControl("aia_actualcloseddate").setVisible(false);
            formContext.getAttribute("aia_actualcloseddate").setRequiredLevel("none");
        }

        if (inputdata != null && inputdata.issueId != undefined) {
            let lookupData2 = [
                {
                    "entityType": inputdata.issueEntity,
                    "id": inputdata.issueId,
                    "name": inputdata.issueName
                }
            ]

            let issueTitle = inputdata.issueTitle;

            formContext.getAttribute('aia_relatedissue').setValue(lookupData2);
            formContext.getAttribute('aia_relatedissuetitle').setValue(issueTitle);
        }

        if (actionId == "") {

            let lookupData = [
                {
                    "entityType": inputdata.entityName,
                    "id": inputdata.reviewId,
                    "name": inputdata.reviewName
                }
            ]

            formContext.getAttribute('aia_relatedreview').setValue(lookupData);


        } else {
            var hideBotton = window.top.document.getElementById("WebResource_new_1");
            if (hideBotton != null) {
                hideBotton.style.opacity = 1;
            }

            if (inputdata != null && inputdata.view != undefined && inputdata.view == true) {
                formContext.ui.tabs.forEach(function (tab) {
                    tab.sections.forEach(function (section) {
                        section.controls.forEach(function (control) {
                            control.setDisabled(true);
                        })
                    });
                });
            }
        }

        formContext.getControl("aia_relatedreview").setDisabled(true);
        formContext.getControl("aia_relatedissuetitle").setDisabled(true);
        formContext.getControl("aia_relatedissue").addPreSearch(CRMSdk.preIssueSearch);


        var actionStatus = formContext.getAttribute('aia_actionstatus').getValue();
        if (actionId != "" && actionStatus == "589450001") {
            formContext.ui.tabs.forEach(function (tab) {
                tab.sections.forEach(function (section) {
                    section.controls.forEach(function (control) {
                        control.setDisabled(true);
                    })
                });
            });
        }


        localStorage.setItem("ActionStatus", actionStatus);
    }

    this.preIssueSearch = function () {
        var review = formContext.getAttribute("aia_relatedreview").getValue();
        var filterxml = "<filter type='and'><condition attribute='aia_relatedreview' operator='eq' value='" + review[0].id + "'/><condition attribute='aia_issuestatus' operator='ne' value='589450001'/></filter>";
        formContext.getControl("aia_relatedissue").addCustomFilter(filterxml, "aia_aia_crm_issue");
    }

    this.updateRelatedIssueTitle = function (executionContext) {
        var formContext = executionContext.getFormContext();
        var relatedIssue = formContext.getAttribute('aia_relatedissue').getValue();

        if (relatedIssue != null) {
            var issueId = relatedIssue[0].id;
            Xrm.WebApi.retrieveRecord("aia_aia_crm_issue", issueId, "?$select=aia_issuetitle").then(function (res) {
                formContext.getAttribute('aia_relatedissuetitle').setValue(res.aia_issuetitle);
            }, function (error) {
                console.log(error);
            });
        } else {
            formContext.getAttribute('aia_relatedissuetitle').setValue("");
        }
    }

    this.getTeamId = function (BU, Confidential, RecordStatus) {
        var obj;
        var teamColl = [];
        switch (BU) {
            // case this.CRMBusinessUnit.AIAHongKongMacau:
            //     obj = CRMTeamList.CRMTeam.AIAHongKongMacau;
            //     break;
            // case this.CRMBusinessUnit.AIASingapore:
            //     obj = CRMTeamList.CRMTeam.AIASingapore;
            //     break;
            // case this.CRMBusinessUnit.AIAGroup:
            //     obj = CRMTeamList.CRMTeam.AIAGroup;
            //     break;
            // case this.CRMBusinessUnit.AIAAustralia:
            //     obj = CRMTeamList.CRMTeam.AIAAustralia;
            //     break;
            // case this.CRMBusinessUnit.AIAChina:
            //     obj = CRMTeamList.CRMTeam.AIAChina;
            //     break;
            // case this.CRMBusinessUnit.AIABrunei:
            //     obj = CRMTeamList.CRMTeam.AIABrunei;
            //     break;
            // case this.CRMBusinessUnit.AIAKorea:
            //     obj = CRMTeamList.CRMTeam.AIAKorea;
            //     break;
            // case this.CRMBusinessUnit.AIAMalaysia:
            //     obj = CRMTeamList.CRMTeam.AIAMalaysia;
            //     break;
            // case this.CRMBusinessUnit.AIAPensionTrustee:
            //     obj = CRMTeamList.CRMTeam.AIAPensionTrustee;
            //     break;
            // case this.CRMBusinessUnit.AIASriLanka:
            //     obj = CRMTeamList.CRMTeam.AIASriLanka;
            //     break;
            // case this.CRMBusinessUnit.AIATaiwan:
            //     obj = CRMTeamList.CRMTeam.AIATaiwan;
            //     break;
            // case this.CRMBusinessUnit.AIAThailand:
            //     obj = CRMTeamList.CRMTeam.AIAThailand;
            //     break;
            // case this.CRMBusinessUnit.AIAVietnam:
            //     obj = CRMTeamList.CRMTeam.AIAVietnam;
            //     break;
            case this.CRMBusinessUnit.GroupOffice: obj = CRMTeamList.CRMTeam.GroupOffice; break;
            case this.CRMBusinessUnit.Australia: obj = CRMTeamList.CRMTeam.Australia; break;
            case this.CRMBusinessUnit.Bermuda: obj = CRMTeamList.CRMTeam.Bermuda; break;
            case this.CRMBusinessUnit.Brunei: obj = CRMTeamList.CRMTeam.Brunei; break;
            case this.CRMBusinessUnit.Cambodia: obj = CRMTeamList.CRMTeam.Cambodia; break;
            case this.CRMBusinessUnit.China: obj = CRMTeamList.CRMTeam.China; break;
            case this.CRMBusinessUnit.HongKongAIAInternational: obj = CRMTeamList.CRMTeam.HongKongAIAInternational; break;
            case this.CRMBusinessUnit.HongKongBlueCross: obj = CRMTeamList.CRMTeam.HongKongBlueCross; break;
            case this.CRMBusinessUnit.HongKongConsumerServices: obj = CRMTeamList.CRMTeam.HongKongConsumerServices; break;
            case this.CRMBusinessUnit.HongKongEverestLife: obj = CRMTeamList.CRMTeam.HongKongEverestLife; break;
            case this.CRMBusinessUnit.HongKongInvestmentManagement: obj = CRMTeamList.CRMTeam.HongKongInvestmentManagement; break;
            case this.CRMBusinessUnit.HongKongTrustee: obj = CRMTeamList.CRMTeam.HongKongTrustee; break;
            case this.CRMBusinessUnit.MacauAIAInternational: obj = CRMTeamList.CRMTeam.MacauAIAInternational; break;
            case this.CRMBusinessUnit.India: obj = CRMTeamList.CRMTeam.India; break;
            case this.CRMBusinessUnit.Indonesia: obj = CRMTeamList.CRMTeam.Indonesia; break;
            case this.CRMBusinessUnit.Korea: obj = CRMTeamList.CRMTeam.Korea; break;
            case this.CRMBusinessUnit.MalaysiaAIABerhad: obj = CRMTeamList.CRMTeam.MalaysiaAIABerhad; break;
            case this.CRMBusinessUnit.MalaysiaGeneralBerhad: obj = CRMTeamList.CRMTeam.MalaysiaGeneralBerhad; break;
            case this.CRMBusinessUnit.MalaysiaAPAM: obj = CRMTeamList.CRMTeam.MalaysiaAPAM; break;
            case this.CRMBusinessUnit.MalaysiaTakaful: obj = CRMTeamList.CRMTeam.MalaysiaTakaful; break;
            case this.CRMBusinessUnit.MalaysiaSharedService: obj = CRMTeamList.CRMTeam.MalaysiaSharedService; break;
            case this.CRMBusinessUnit.Myanmar: obj = CRMTeamList.CRMTeam.Myanmar; break;
            case this.CRMBusinessUnit.NewZealand: obj = CRMTeamList.CRMTeam.NewZealand; break;
            case this.CRMBusinessUnit.PhilippinesInvestmentManagement: obj = CRMTeamList.CRMTeam.PhilippinesInvestmentManagement; break;
            case this.CRMBusinessUnit.PhilippinesPhilamLife: obj = CRMTeamList.CRMTeam.PhilippinesPhilamLife; break;
            case this.CRMBusinessUnit.PhilippinesBPI: obj = CRMTeamList.CRMTeam.PhilippinesBPI; break;
            case this.CRMBusinessUnit.Singapore: obj = CRMTeamList.CRMTeam.Singapore; break;
            case this.CRMBusinessUnit.SingaporeInvestmentManagement: obj = CRMTeamList.CRMTeam.SingaporeInvestmentManagement; break;
            case this.CRMBusinessUnit.SingaporeFinancialAdvisers: obj = CRMTeamList.CRMTeam.SingaporeFinancialAdvisers; break;
            case this.CRMBusinessUnit.SriLanka: obj = CRMTeamList.CRMTeam.SriLanka; break;
            case this.CRMBusinessUnit.Taiwan: obj = CRMTeamList.CRMTeam.Taiwan; break;
            case this.CRMBusinessUnit.Thailand: obj = CRMTeamList.CRMTeam.Thailand; break;
            case this.CRMBusinessUnit.Vietnam: obj = CRMTeamList.CRMTeam.Vietnam; break;
        }

        teamColl.push({
            "Type": "BUInitial",
            "Id": obj.InitalConfidential
        }, {
            "Type": "Admin",
            "Id": CRMTeamList.CRMTeam.AIACRMAdmin.SystemAdmin
        })

        if (!Confidential) {
            teamColl.push({
                "Type": "BUInitial",
                "Id": obj.InitalNormal
            }, {
                "Type": "BUAdmin",
                "Id": obj.BUAdmin
            })
        }

        if (RecordStatus == this.RecordStatus.Published) {
            teamColl.push({
                "Type": "GroupInitial",
                "Id": CRMTeamList.CRMTeam.GroupOffice.InitalConfidential
            }, {
                "Type": "BUVisitor",
                "Id": obj.VisitorConfidential
            }, {
                "Type": "GroupVisitor",
                "Id": CRMTeamList.CRMTeam.GroupOffice.VisitorConfidential
            })

            if (!Confidential) {
                teamColl.push({
                    "Type": "GroupInitial",
                    "Id": CRMTeamList.CRMTeam.GroupOffice.InitalNormal
                }, {
                    "Type": "BUVisitor",
                    "Id": obj.VisitorNormal
                }, {
                    "Type": "GroupVisitor",
                    "Id": CRMTeamList.CRMTeam.GroupOffice.VisitorNormal
                })
            }
        }
        return teamColl;
    }
}).call(CRMSdk)

String.prototype.format = function () {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function (match, number) {
        return typeof args[number] != 'undefined'
            ? args[number]
            : match;
    });
};
