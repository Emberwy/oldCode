using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lk_wa_app_s_recruitment.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens; 
using Microsoft.Extensions.Configuration;
using lk_wa_app_s_recruitment.Infrastructure.Components.Exceptions;
using lk_wa_app_s_recruitment.Infrastructure.Components.Tools;
using lk_wa_app_s_recruitment.Interfaces;
using lk_wa_app_s_recruitment.Models;
 
namespace lk_wa_app_s_recruitment.Filters
{
    public class AuthenticationFilterAttribute : ActionFilterAttribute
    { 
        private readonly RecruitmentDBContext _context;

        public AuthenticationFilterAttribute(RecruitmentDBContext context,IUserService userService,IConfiguration configuration)
        {
            this._context = context;  
          
        } 

        public override async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            try  
            {
                string userEmail = context.HttpContext.Request.Headers["userEmail"];
                string token = context.HttpContext.Request.Headers["token"];
                string path = context.HttpContext.Request.Path.Value;
                 Console.WriteLine(string.Format("Head token: {0}", token));
                 Console.WriteLine(string.Format("Head path: {0}", path));
                
                if(string.IsNullOrEmpty(userEmail) || string.IsNullOrEmpty(token)) 
                {
                    context.Result = new UnauthorizedResult();
                    return;
                }
                else
                {
                    var mappings = await _context.Recruitment_Token.Where(t => t.User_Code.ToLower() == userEmail.ToLower() && t.Token == token).ToListAsync();
                     Console.WriteLine(string.Format("db tokenCount: {0}", mappings.Count));
                    if (mappings.Count > 0)
                    {
                        //check if token expires 
                        var mapping = mappings[0];
                       
                        if(!mapping.Valid_Date.HasValue) //return 401 unauthorized if no valid date
                        {
                             Console.WriteLine("token's Valid_Date don't HasValue");
                            context.Result = new UnauthorizedResult();
                            return;
                        }
 
                        Console.WriteLine(path);
                        DateTime validDate = mapping.Valid_Date.Value;
                        Console.WriteLine(validDate);
                        DateTime nowDate = DateTime.Now;
                        Console.WriteLine(nowDate);
                        DateTime adjustedDate = nowDate.AddHours(1);
                        var timeDiff = adjustedDate - validDate;
                        Console.WriteLine(timeDiff);
                        if(timeDiff.TotalMinutes > 60)
                        {
                             Console.WriteLine("token overdue");
                            context.Result = new UnauthorizedResult();
                            return;
                        }

                        await base.OnActionExecutionAsync(context, next);
                    }
                    else
                    {
                         Console.WriteLine("don't have token ");
                        context.Result = new UnauthorizedResult();
                        return;
                    }
                }
                
            }
            catch (Exception)
            {

            }
            
        }

  
        /*public override void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var userEmail = context.HttpContext.Request.Headers["userEmail"];
                var token = context.HttpContext.Request.Headers["token"];
                var mapping = _context.Recruitment_Token.Where(t => t.User_Code.ToLower() == userEmail && t.Token == token).ToList();
                if(mapping.Count > 0)
                {
                    base.OnActionExecuting(context);
                }
                else
                {
                    throw new Exception("Invalid token");
                }
            }
            catch (Exception)
            {

            }
            
        }*/

        /*public void OnAuthorization(AuthorizationFilterContext context)
        {
            try
            {
                var userEmail = context.HttpContext.Request.Headers["userEmail"];
                var token = context.HttpContext.Request.Headers["token"];
                var mapping = _context.Recruitment_Token.Where(t => t.User_Code.ToLower() == userEmail && t.Token == token).ToList();
                if (mapping.Count == 0)
                {
                    context.Result = new UnauthorizedResult();
                    return;
                }
                else { }
            }
            catch (Exception)
            {

            }
        }*/
    }
}
