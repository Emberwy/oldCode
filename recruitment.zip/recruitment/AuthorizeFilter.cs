using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lk_wa_app_s_recruitment.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;
using System.IO;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens; 
using Microsoft.Extensions.Configuration;
using lk_wa_app_s_recruitment.Infrastructure.Components.Exceptions;
using lk_wa_app_s_recruitment.Infrastructure.Components.Tools;
using lk_wa_app_s_recruitment.Interfaces;
using lk_wa_app_s_recruitment.Models;

namespace lk_wa_app_s_recruitment.Filters
{
    public class AuthorizeFilter: ActionFilterAttribute,IAsyncAuthorizationFilter
    {

         private readonly IConfiguration _iConfiguration;
          private readonly IUserService _userService;
        public AuthorizeFilter(RecruitmentDBContext context,IUserService userService,IConfiguration configuration)
        {

             _userService = userService;
            _iConfiguration = configuration;
        } 

     public async Task<JwtSecurityToken> Validate(string token)
        {
            string tenentId = File.Exists("../kvmnt/AppTenentId") ? File.ReadAllText("../kvmnt/AppTenentId") : _iConfiguration["Authorize:TenentId"];
            string clientId = File.Exists("../kvmnt/AppClientId") ? File.ReadAllText("../kvmnt/AppClientId") : _iConfiguration["Authorize:ClientId"];

            // tenentId = "7f2c1900-9fd4-4b89-91d3-79a649996f0a";
            // //clientId = "f3a46f81-91f2-4bc0-b330-3037e6d3314c";
            // clientId = "3480db29-f851-4fd0-ad30-b94080dcf7e7";

            string stsDiscoveryEndpoint = $"https://login.microsoftonline.com/{tenentId}/.well-known/openid-configuration?appid={clientId}";
            var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever());
            OpenIdConnectConfiguration config = await configManager.GetConfigurationAsync();

            TokenValidationParameters validationParameters = new TokenValidationParameters
            {
                ValidAudience = clientId,
                ValidIssuer = $"https://sts.windows.net/{tenentId}/",
                ValidateAudience = false,
                ValidateIssuer = false, 
                IssuerSigningKeys = config.SigningKeys,
                ValidateLifetime = true
            };
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            //IdentityModelEventSource.ShowPII = true;
            SecurityToken jwt;
            try
            {
                var result = tokenHandler.ValidateToken(token, validationParameters, out jwt);
                return jwt as JwtSecurityToken;
            }
            catch (Exception e) { 
    
                throw new DomainException("Token has expired"); 
                }
        }
       

  public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var isPass = context.ActionDescriptor.EndpointMetadata.Any(e => e.GetType() == typeof(AllowAnonymousAttribute));  
            if (!isPass)
            {   
                try
                {
                    context.HttpContext.Request.Headers.TryGetValue("Authorization", out var apiKeyHeaderValues);
                    // var token="eyJ0eXAiOiJKV1QiLCJub25jZSI6ImNUd0JXMHVBeFZOR1ZGSnFkeWRXbXZONzJaODc0cHA3aUVBcEJHWjhORU0iLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC83ZjJjMTkwMC05ZmQ0LTRiODktOTFkMy03OWE2NDk5OTZmMGEvIiwiaWF0IjoxNjgxNzE2NDUyLCJuYmYiOjE2ODE3MTY0NTIsImV4cCI6MTY4MTcyMTc2NiwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhUQUFBQWNSVTlBSE03NTJVbVp5SWpVKzVJNjZmNldMVXdwU0lrd0lFc0ZzNXNiclZKaGN4bEhJNm9weWZzZkNsQldzWlMiLCJhbXIiOlsicHdkIiwicnNhIl0sImFwcF9kaXNwbGF5bmFtZSI6ImFwcC1zZy1zLXNkYSIsImFwcGlkIjoiMzQ4MGRiMjktZjg1MS00ZmQwLWFkMzAtYjk0MDgwZGNmN2U3IiwiYXBwaWRhY3IiOiIxIiwiZGV2aWNlaWQiOiJlYmZlM2RkNy0zMWE5LTQwZGItYTg3NS01NTEwMTVlZjBhNjkiLCJmYW1pbHlfbmFtZSI6IkxpIiwiZ2l2ZW5fbmFtZSI6IkphY2siLCJpZHR5cCI6InVzZXIiLCJpcGFkZHIiOiIyMDkuOS4yMTIuNyIsIm5hbWUiOiJMaSwgSmFjay1KMSIsIm9pZCI6Ijg5MjZkOTdmLTUzODItNGUzNi1iYTAxLTVhNWFhNjk0Yjg1NyIsIm9ucHJlbV9zaWQiOiJTLTEtNS0yMS0yMTc4NzU1ODAzLTE0NzQzNTM4ODEtMTczMzYwODA1Mi03NDg0MzQiLCJwbGF0ZiI6IjMiLCJwdWlkIjoiMTAwMzIwMDI0MDU0Rjg4OSIsInJoIjoiMC5BU1VBQUJrc2Y5U2ZpVXVSMDNtbVNabHZDZ01BQUFBQUFBQUF3QUFBQUFBQUFBQWxBTlUuIiwic2NwIjoiZW1haWwgb3BlbmlkIFVzZXIuUmVhZCBwcm9maWxlIiwic2lnbmluX3N0YXRlIjpbImR2Y19tbmdkIiwiZHZjX2NtcCIsImR2Y19kbWpkIiwiaW5rbm93bm50d2siLCJrbXNpIl0sInN1YiI6InY1OWlWblNDd28zSzhoX2ZRaXdPOEY5N0lRWnluYlN0bk9PNEswbG5ySUkiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiQVMiLCJ0aWQiOiI3ZjJjMTkwMC05ZmQ0LTRiODktOTFkMy03OWE2NDk5OTZmMGEiLCJ1bmlxdWVfbmFtZSI6IkphY2stSi5MaUBhaWEuY29tIiwidXBuIjoiSmFjay1KLkxpQGFpYS5jb20iLCJ1dGkiOiItV0pHNmFKS0FVV1k2emhuSXRzWkFBIiwidmVyIjoiMS4wIiwid2lkcyI6WyJiNzlmYmY0ZC0zZWY5LTQ2ODktODE0My03NmIxOTRlODU1MDkiXSwieG1zX3N0Ijp7InN1YiI6ImdRRjJlcjZNRmdheElSUnRyY0l1WFByVFpKTWgwaVRzQVJVN3pod3FVQUUifSwieG1zX3RjZHQiOjEzNjM2MDI5NjF9.eAmJaNPMgANiU4-ZlH1_0IYkRFCk-p73J5VcxIoC2RKIou-fongrNVaIZN_O73IYQ4uUn0LMYOn__KbmKO9AqCYZPK2v_UX6_TeNAPXASzI34saLCQczFHsk-c6RGws4ltfFMHUjARuu4H9aNiauatGd4DVST76bV_128cWTocVONb5d4yeBmsZMBi6P0qVoziPkhcIkMNRpQ2kiYxVEAgd9_X40vCUAZlH3Y0mLSdPx9o6Y2Fvh7uCUG2wGXDR4o6y0FW8beUgTXtoW-z5L0s7uURKr0jsp2vlAqrQhVH3X5pxhv-Xd_bNdxXwevKnl6aMA8j711-JIYixaoFd33g";
                    var token = apiKeyHeaderValues.FirstOrDefault().Replace("Bearer ", "");
                    // var jwtToken = await Validate(token);
                    var jwtToken = new JwtSecurityTokenHandler().ReadJwtToken(token);
                    var method = context.HttpContext.Request.Method.ToLowerInvariant(); 
                    var route = context.HttpContext.Request.Path.Value;
                    context.HttpContext.Request.Headers.TryGetValue("Useremail", out var userEmail);
                    var email = jwtToken.Claims.FirstOrDefault(e => e.Type == "upn")?.Value;
                 
                    if(userEmail.ToString().ToLower()!=email.ToLower())
                    {
                 
                     context.Result = new StatusCodeResult(401);
                    }
                   
               
                }
                catch
                {
                    context.Result = new StatusCodeResult(401);
                    //throw new DomainException("Token has expired");
                }
            }
        }
    }
}
