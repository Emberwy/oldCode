using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks; 
using Newtonsoft.Json;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using lk_wa_app_s_recruitment.Interfaces;
using lk_wa_app_s_recruitment.Models.Authorize;
 
namespace lk_wa_app_s_recruitment.Services.User
{
    public class AuthorizeService:IAuthorizeService 
    { 
       private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _iConfiguration;

        public AuthorizeService(IHttpClientFactory httpClientFactory, IConfiguration configuration
           , IMapper mapper)
        {
            _httpClientFactory = httpClientFactory;
            _iConfiguration = configuration;
        } 
        public async Task<TokenViewModel> GetAccessToken(string code)
        {
            using (HttpClient httpClient = _httpClientFactory.CreateClient("cishttpClientPolicy"))
            {
                string tenentId = File.Exists("../kvmnt/TenentId") ? File.ReadAllText("../kvmnt/TenentId") : _iConfiguration["Authorize:TenentId"];
                string _url = $"https://login.microsoftonline.com/{tenentId}/oauth2/v2.0/token";
                string clientId= File.Exists("../kvmnt/ClientId") ? File.ReadAllText("../kvmnt/ClientId") : _iConfiguration["Authorize:ClientId"];
                // string clientId= File.Exists("../mnt/secrets-store/secret-lk01-sea-s-ann-db01-id") ? File.ReadAllText("../mnt/secrets-store/secret-lk01-sea-s-ann-db01-id") : _iConfiguration["Authorize:ClientId"];
                // string clientSecret = File.Exists("../kvmnt/ClientSecret") ? File.ReadAllText("../kvmnt/ClientSecret") : _iConfiguration["Authorize:ClientSecret"];
                string clientSecret = File.Exists("../mnt/secrets-store/app-sl-u-recruit") ? File.ReadAllText("../mnt/secrets-store/app-sl-u-recruit") : _iConfiguration["Authorize:ClientSecret"];
                var content = new StringContent($"client_id={clientId}&grant_type=authorization_code&code={code}&client_secret={clientSecret}&scope={clientId}/.default openid profile offline_access");
                // var content = new StringContent($"client_id={clientId}&grant_type=authorization_code&code={code}&client_secret={clientSecret}&scope=https://graph.microsoft.com/.default openid profile offline_access");
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");  
                var response=await httpClient.PostAsync(_url, content);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    var token = JsonConvert.DeserializeObject<TokenViewModel>(result);
                    return token;
                }
                else
                {
                    return null;
                }
            }
        }
        public async Task<TokenViewModel> RefreshToken(string refreshtoken)
        {
            using (HttpClient httpClient = _httpClientFactory.CreateClient("cishttpClientPolicy"))
            {
                string tenentId = File.Exists("../kvmnt/TenentId") ? File.ReadAllText("../kvmnt/TenentId") : _iConfiguration["Authorize:TenentId"];
                string _url = $"https://login.microsoftonline.com/{tenentId}/oauth2/v2.0/token";
                string clientId = File.Exists("../kvmnt/ClientId") ? File.ReadAllText("../kvmnt/ClientId") : _iConfiguration["Authorize:ClientId"];
                // string clientSecret = File.Exists("../kvmnt/ClientSecret") ? File.ReadAllText("../kvmnt/ClientSecret") : _iConfiguration["Authorize:ClientSecret"];
                  string clientSecret = File.Exists("../mnt/secrets-store/app-sl-u-recruit") ? File.ReadAllText("../mnt/secrets-store/app-sl-u-recruit") : _iConfiguration["Authorize:ClientSecret"];
                // var content = new StringContent($"client_id={clientId}&grant_type=refresh_token&refresh_token={refreshtoken}&client_secret={clientSecret}&scope={clientId}/.default openid profile offline_access");
                var content = new StringContent($"client_id={clientId}&grant_type=refresh_token&refresh_token={refreshtoken}&client_secret={clientSecret}&scope=https://graph.microsoft.com/.default openid profile offline_access");
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                var response = await httpClient.PostAsync(_url, content);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    var token = JsonConvert.DeserializeObject<TokenViewModel>(result);
                    return token;
                }
                else
                {
                    return null;
                }
            }
        }
    } 
}
