using System.IO.Enumeration;
using lk_wa_app_s_recruitment.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;


namespace lk_wa_app_s_recruitment.Data
{
    public class RecruitmentDBContext : DbContext
    {
        // public RecruitmentDBContext(DbContextOptions<RecruitmentDBContext> options)
        //     : base(options)
        // {
        //     // using
        //     var conn = (SqlConnection)this.Database.GetDbConnection();
        //     Console.WriteLine(string.Format("connection string in constructor: {0}", conn.ConnectionString));
        //     Console.WriteLine(string.Format("Token string in constructor: {0}", conn.AccessToken));
        // }
        public DbSet<Recruitment_Leads> Recruitment_Leads { get; set; }
        public DbSet<Recruitment_Action> Recruitment_Action { get; set; }
        public DbSet<Recruitment_AdditionalDetails> Recruitment_AdditionalDetails { get; set; }
        public DbSet<Recruitment_InductionAttendence> Recruitment_InductionAttendence { get; set; }
        public DbSet<Recruitment_IntroducePolicies> Recruitment_IntroducePolicies { get; set; }
        public DbSet<Recruitment_IRCLExamResult> Recruitment_IRCLExamResult { get; set; }
        public DbSet<Recruitment_SupportingDocuments> Recruitment_SupportingDocuments { get; set; }
        public DbSet<Recruitment_Task> Recruitment_Task { get; set; }
        public DbSet<Recruitment_WP> Recruitment_WP { get; set; }
        public DbSet<Recruitment_WPM> Recruitment_WPM { get; set; }
        public DbSet<Recruitment_Bumapping> Recruitment_BUData { get; set; }
        // // try remove bug
        // public DbSet<Recruitment_Bumapping> Recruitment_Bumapping{get;set;}
        //  public DbSet<Recruitment_BUData> Recruitment_BUData { get; set; }

        public DbSet<Recruitment_KV> Recruitment_KV { get; set; }
        public DbSet<Recruitment_Token> Recruitment_Token { get; set; }
        public DbSet<Recruitment_UserRole> Recruitment_UserRole { get; set; }
        public DbSet<Recruitment_RoleMapping> Recruitment_RoleMapping { get; set; }
        public DbSet<Recruitment_Image> Recruitment_Image{get;set;}
        public static Int32 i=0;
        public RecruitmentDBContext(DbContextOptions<RecruitmentDBContext> options) : base(options)  
        {  
            if(i==0){
              addAll();  
            }
        }   
  
     
  
       
   
        // //下面是初始化内存数据库逻辑
        private void addAll()
        {
          Recruitment_Leads.AddRange(readJson<Recruitment_Leads>());
        //   Recruitment_BUData.AddRange(readJson<Recruitment_BUData>());
        //   Recruitment_BUData.AddRange(readJson<Recruitment_Bumapping>());
          Recruitment_Action.AddRange(readJson<Recruitment_Action>());
          Recruitment_AdditionalDetails.AddRange(readJson<Recruitment_AdditionalDetails>());
          Recruitment_InductionAttendence.AddRange(readJson<Recruitment_InductionAttendence>());
          Recruitment_IntroducePolicies.AddRange(readJson<Recruitment_IntroducePolicies>());
          Recruitment_IRCLExamResult.AddRange(readJson<Recruitment_IRCLExamResult>());
          Recruitment_SupportingDocuments.AddRange(readJson<Recruitment_SupportingDocuments>());
          Recruitment_Task.AddRange(readJson<Recruitment_Task>());
          Recruitment_WP.AddRange(readJson<Recruitment_WP>());
          Recruitment_WPM.AddRange(readJson<Recruitment_WPM>());
          Recruitment_KV.AddRange(readJson<Recruitment_KV>());
          Recruitment_Token.AddRange(readJson<Recruitment_Token>());
          Recruitment_UserRole.AddRange(readJson<Recruitment_UserRole>());
          Recruitment_RoleMapping.AddRange(readJson<Recruitment_RoleMapping>());
          SaveChangesAsync();
          i++;

        }

        private List<T> readJson<T>(){
            
             string[] files1 = Directory.GetFiles("C:\\csv","*.txt");
              string fileName=typeof(T).Name;
              string json="";
             foreach(string file in files1){
                string fn=file.Replace("C:\\csv\\","").Replace(".txt","");
               if(fn==fileName){
                  json=File.ReadAllText(file);
                 Type t=Type.GetType(fileName);
               }    
              
             }
              return JsonConvert.DeserializeObject<List<T>>(json);
        }
    }
}
