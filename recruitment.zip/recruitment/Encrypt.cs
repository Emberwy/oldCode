using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace lk_wa_app_s_recruitment.Data
{
    public static class NBEncrypt
    {
        public static string EncryptText(string input, string key)
        {
            byte[] bytesToBeEncrypted = Encoding.UTF8.GetBytes(input);
            byte[] passwordBytes = Encoding.UTF8.GetBytes(key);

            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

            byte[] bytesEncrypted = AESEncryptBytes(bytesToBeEncrypted, passwordBytes);

            string result = Convert.ToBase64String(bytesEncrypted);

            return result;
        }

        private static byte[] AESEncryptBytes(byte[] bytesToBeEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes = null;

            var saltBytes = new byte[256] { 47,10,63,117,114,180,151,228,16,176,245,83,63,89,96,14,
218,8,104,173,131,166,199,15,47,150,223,192,144,76,58,131,
124,190,226,151,207,12,103,156,41,79,124,123,182,224,129,37,
164,41,224,164,193,201,84,15,86,72,117,160,34,7,181,197,
150,246,63,152,90,187,179,90,108,255,131,51,39,1,237,169
,68,152,101,0,75,103,103,192,33,94,123,160,56,50,41,74,
218,197,168,220,175,182,186,174,36,89,147,148,228,238,163,154
,13,208,88,159,150,51,88,221,143,204,181,29,20,156,117,103
,83,118,31,121,63,78,16,6,20,241,129,69,80,116,234,18
,65,118,146,47,26,179,78,31,201,50,73,61,102,52,191,230
,76,210,193,30,38,196,136,196,25,170,164,254,7,171,9,208,
150,32,107,193,218,223,226,220,175,129,87,241,122,234,57,30,
219,130,45,236,70,76,239,0,192,205,185,103,151,49,7,139
,45,201,247,243,228,137,225,57,230,1,148,131,18,134,144,218
,38,216,240,200,39,159,237,84,49,36,227,84,234,77,103,13
,4,227,51,174,14,202,120,239,83,177,83,152,25,142,123,99 };

            using (var ms = new MemoryStream())
            {
                using (var AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(32);
                    AES.IV = key.GetBytes(16);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateEncryptor(),
                        CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length);
                        cs.Close();
                    }

                    encryptedBytes = ms.ToArray();
                }
            }

            return encryptedBytes;
        }

        public static string DecryptText(string input, string key)
        {
            try
            {
                byte[] bytesToBeDecrypted = Convert.FromBase64String(input);

                byte[] passwordBytes = Encoding.UTF8.GetBytes(key);

                passwordBytes = SHA256.Create().ComputeHash(passwordBytes);

                byte[] bytesDecrypted = AESDecryptBytes(bytesToBeDecrypted, passwordBytes);

                string result = Encoding.UTF8.GetString(bytesDecrypted);

                return result;
            }
            catch (Exception)
            {
                return input;
            }

        }

        private static byte[] AESDecryptBytes(byte[] bytesToBeDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes = null;

            var saltBytes = new byte[256] { 47,10,63,117,114,180,151,228,16,176,245,83,63,89,96,14,
218,8,104,173,131,166,199,15,47,150,223,192,144,76,58,131,
124,190,226,151,207,12,103,156,41,79,124,123,182,224,129,37,
164,41,224,164,193,201,84,15,86,72,117,160,34,7,181,197,
150,246,63,152,90,187,179,90,108,255,131,51,39,1,237,169
,68,152,101,0,75,103,103,192,33,94,123,160,56,50,41,74,
218,197,168,220,175,182,186,174,36,89,147,148,228,238,163,154
,13,208,88,159,150,51,88,221,143,204,181,29,20,156,117,103
,83,118,31,121,63,78,16,6,20,241,129,69,80,116,234,18
,65,118,146,47,26,179,78,31,201,50,73,61,102,52,191,230
,76,210,193,30,38,196,136,196,25,170,164,254,7,171,9,208,
150,32,107,193,218,223,226,220,175,129,87,241,122,234,57,30,
219,130,45,236,70,76,239,0,192,205,185,103,151,49,7,139
,45,201,247,243,228,137,225,57,230,1,148,131,18,134,144,218
,38,216,240,200,39,159,237,84,49,36,227,84,234,77,103,13
,4,227,51,174,14,202,120,239,83,177,83,152,25,142,123,99 };

            using (var ms = new MemoryStream())
            {
                using (var AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    AES.Key = key.GetBytes(32);
                    AES.IV = key.GetBytes(16);

                    AES.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(ms, AES.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
                        cs.Close();
                    }

                    decryptedBytes = ms.ToArray();
                }
            }

            return decryptedBytes;
        }
    }
}
