using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using lk_wa_app_s_recruitment.Data;
using lk_wa_app_s_recruitment.Interfaces;
using lk_wa_app_s_recruitment.Services;
using lk_wa_app_s_recruitment.Services.User;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore.Storage;
using Polly;
using Polly.Extensions.Http;
using Azure.Storage.Blobs; 
using Azure.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection; 
using lk_wa_app_s_recruitment.Filters; 
using lk_wa_app_s_recruitment.Infrastructure.Components.Tools;
using AutoMapper; 


using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace lk_wa_app_s_recruitment
{
    public class Startup
    {
        readonly string RectAllowSpecificOrigins = "_RectAllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<Filters.AuthenticationFilterAttribute>();
            services.AddScoped<Filters.AuthorizeFilter>();
            services.AddScoped<Filters.SetResponseHeaderFilterAttribute>();
            string conn1 = "Server=tcp:lkazessdb0003.database.windows.net,1433; Database=DTAANNDATSSDB01;";
            services.AddCors(options =>
            {
                options.AddPolicy(RectAllowSpecificOrigins,
                builder =>
                {
                    builder.WithOrigins("https://aiacom.sharepoint.com").AllowAnyMethod().AllowAnyHeader();
                });
            });


            // 使用内存数据库
            InMemoryDatabaseRoot _databaseRoot = new InMemoryDatabaseRoot();
            string _connectionString = Guid.NewGuid().ToString();
            services.AddEntityFrameworkInMemoryDatabase();
            services.AddDbContext<RecruitmentDBContext>(options =>
            
                options.UseInMemoryDatabase(_connectionString, _databaseRoot) 

            );
            services.AddScoped<RecruitmentDBContext>();
            services.AddAutoMapper(typeof(Startup));

            // services.AddDbContext<RecruitmentDBContext>(options =>
            // {
            //    options.UseSqlServer(conn1);
            //     options.AddInterceptors(new AadAuthenticationDbConnectionInterceptor());
               
            // });
            #region �����Լ�����Ľӿ�
            services.AddTransient<IActionService, ActionService>();
            services.AddScoped<ILeadService, LeadService>();
            services.AddScoped<ITaskService, TaskService>(); 
            services.AddScoped<IWPMService, WPMService>(); 
            services.AddScoped<IWPService, WPService>();
            services.AddScoped<IIRCSLExamResultService, IRCSLExamResultService>();
            services.AddScoped<IBumappingService, BumappingService>();
            services.AddScoped<IAdditionalDetailsService, AdditionalDetailsService>();
            services.AddScoped<IIntroducePolicyService, IntroducePolicyService>();
            services.AddScoped<IInductionAttendenceService, InductionAttendenceService>();
            
               
            services.AddTransient<IUserService,UserService>();    
            services.AddTransient<IAuthorizeService, AuthorizeService>(); 
            #endregion

            services.AddMemoryCache(o=>o.SizeLimit=100);
            services.AddSwaggerGen(); 
            services.AddControllers();

            #region addAzure
 var retryPolicy = Polly.Extensions.Http.HttpPolicyExtensions.HandleTransientHttpError().RetryAsync(3);
            var noOp = Policy.NoOpAsync().AsAsyncPolicy<System.Net.Http.HttpResponseMessage>();
            services.AddHttpClient("cishttpClientPolicy") 
            .AddPolicyHandler(request=> request.Method ==  System.Net.Http.HttpMethod.Get ? retryPolicy: noOp)
            .AddPolicyHandler(Policy.TimeoutAsync<System.Net.Http.HttpResponseMessage>(System.TimeSpan.FromSeconds(10)));
            services.AddResponseCaching();
             services.AddMvc(option =>
            {
                option.Filters.Add<AuthorizeFilter>();
            }).AddJsonOptions(configure => 
            {
                // configure.JsonSerializerOptions.Converters.Add(new DatetimeJsonConverter());
            });

            if (File.Exists("../kvmnt/CISBlobKey"))
            {
                var blobName = File.ReadAllText("../kvmnt/CISBlobName");
                services.AddScoped(x => new BlobServiceClient(new System.Uri(string.Format(Configuration["Azure:Storage:ServiceUri"], blobName)),
  new StorageSharedKeyCredential(blobName, File.ReadAllText("../kvmnt/CISBlobKey"))));
            }
            else
            {
                services.AddScoped(x => new BlobServiceClient(new System.Uri(Configuration["Azure:Storage:ServiceUri"]),
    new StorageSharedKeyCredential(Configuration["Azure:Storage:AccountName"], Configuration["Azure:Storage:AccessKey"])));
            }

            services.AddCors(option =>
            {
                option.AddPolicy("Cors", builder =>
                {
                    builder.AllowAnyMethod()
                    .AllowAnyOrigin()
                    .AllowAnyHeader();
                });
            }); 
            #endregion

        }  
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors(RectAllowSpecificOrigins);
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler(appBuilder =>
                {
                    appBuilder.Run(async context =>
                    {
                        context.Response.StatusCode = 500;
                        await context.Response.WriteAsync("An unexpected fault happened. Try again later.");
                    });
                });
            }

            app.UseHttpsRedirection();

            app.UseSwagger(c =>
            {
                c.RouteTemplate = "recruitment/swagger/{documentName}/swagger.json";
            });
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/recruitment/swagger/v1/swagger.json", "Recruitment API V1");
                c.RoutePrefix = "recruitment/swagger";
            });

            #region ���ز�����swagger
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Recruitment API V1");
            });
            #endregion

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
 
        public class AadAuthenticationDbConnectionInterceptor : DbConnectionInterceptor
        {
            public async Task<string> GetAccessTokenAsync(string clientId, string clientSecret, string authority, string resource, string scope)
            {
                var authContext = new AuthenticationContext(authority, TokenCache.DefaultShared);
                var clientCred = new ClientCredential(clientId, clientSecret);
                var result = await authContext.AcquireTokenAsync(resource, clientCred);

                if (result == null)
                {
                    throw new InvalidOperationException("Could not get token");
                }
                Console.WriteLine(string.Format("Got token: {0}", result.AccessToken));
                return result.AccessToken;
            }
            public override async Task<InterceptionResult> ConnectionOpeningAsync(
                DbConnection connection,
                ConnectionEventData eventData,
                InterceptionResult result,
                CancellationToken cancellationToken)
            {
                var sqlConnection = (SqlConnection)connection;


                string id = ""; //"adedf2a1-997c-4769-9110-5d0788dfc5e0";

                using (StreamReader reader = File.OpenText("../mnt/secrets-store/secret-lk01-sea-s-ann-db01-id"))
                {
                    id = reader.ReadToEnd();
                }

                string ss = ""; // "ukehHBKs._-ZUZs_opGo0FV9Xh1dM9Z9q4";


                using (StreamReader reader = File.OpenText("../mnt/secrets-store/secret-lk01-sea-s-ann-db01-sec"))
                {
                    ss = reader.ReadToEnd();
                }
                //  - The connection doesn't specify a username.
                //
                var connectionStringBuilder = new SqlConnectionStringBuilder(sqlConnection.ConnectionString);
                //if (connectionStringBuilder.DataSource.Contains("database.windows.net", StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(connectionStringBuilder.UserID))
                {
                    var authority = string.Format("https://login.windows.net/{0}", "7f2c1900-9fd4-4b89-91d3-79a649996f0a");
                    var resource = "https://database.windows.net/";
                    var scope = "";
                    var token = await this.GetAccessTokenAsync(id, ss, authority, resource, scope);
                    sqlConnection.AccessToken = token;
                }

                return await base.ConnectionOpeningAsync(connection, eventData, result, cancellationToken);
            }
        }
    }
}
