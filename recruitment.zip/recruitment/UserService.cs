using lk_wa_app_s_recruitment.Data;
using lk_wa_app_s_recruitment.Interfaces;
using lk_wa_app_s_recruitment.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace lk_wa_app_s_recruitment.Services.User 
{
    public class UserService:IUserService  
    {
          private readonly RecruitmentDBContext _context;
        private readonly ILogger _Logger;

        public UserService(RecruitmentDBContext context, ILoggerFactory loggerFactory)
        {
            _context = context;
            _Logger = loggerFactory.CreateLogger("Recrutment_UserService");
        }
 
 
        public List<Recruitment_UserRole> GetAllUsers(){
         
             return _context.Recruitment_UserRole.ToList();
        }
        public List<Recruitment_RoleMapping> GetAllPath(){  
          
             return _context.Recruitment_RoleMapping.ToList();
        }
       

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }

        public async Task<bool> SaveSync()
        {
            return (await _context.SaveChangesAsync() >= 0);
        }
    }
} 
