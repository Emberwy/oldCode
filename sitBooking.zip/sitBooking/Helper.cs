using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using AuthenticationManager = PnP.Framework.AuthenticationManager;

using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;


using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using Microsoft.SharePoint;
using System.Web;
using SharepointCommon;
using Microsoft.Office.Interop.Excel;

namespace sit_booking_job
{
     class Helper
    {
         public static ClientContext GetAppCtx(string siteUrl, string appId, string appSecret)
        {
            try
            {
                AuthenticationManager repositoryAuthenticationManager = new AuthenticationManager();
                ClientContext ctx = repositoryAuthenticationManager.GetACSAppOnlyContext(siteUrl, appId, appSecret);
                return ctx;
            }
            catch
            {
                return null;
            }
        }
         public static void writeLogs(string LogMesg, string LogSrc)
        {
            Console.WriteLine(LogMesg);
            StreamWriter writer = null;
            string sCurDate = System.DateTime.Now.ToString("yyyy-MM-dd");
            try
            {
                if (System.IO.File.Exists(LogSrc))
                    writer = new StreamWriter(LogSrc, true, System.Text.Encoding.GetEncoding("UTF-8"));
                else
                    writer = new StreamWriter(LogSrc, false, System.Text.Encoding.GetEncoding("UTF-8"));
                string sDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:sss");
                writer.WriteLine("<" + sDateTime + "> " + " " + LogMesg);
            }
            catch { }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
        }
           public static string GetAKVSecret(string keyVaultName, string secretName)
        {
            try
            {
                var kvUri = "https://" + keyVaultName + ".vault.azure.net";
                SecretClientOptions options = new SecretClientOptions()
                {
                    Retry =
                    {
                        Delay= TimeSpan.FromSeconds(2),
                        MaxDelay = TimeSpan.FromSeconds(16),
                        MaxRetries = 5,
                        Mode = RetryMode.Exponential
                    }
                };

                var client = new SecretClient(new Uri(kvUri), new DefaultAzureCredential(), options);
                KeyVaultSecret secret = client.GetSecret(secretName);
                Console.WriteLine(secretName);
                Console.WriteLine(secret.Value);
                return secret.Value;
            }
            catch (Exception)
            {
                return "";
            }
        }


    }
}
