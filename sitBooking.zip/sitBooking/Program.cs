
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Dynamic;
using System;
using Microsoft.SharePoint.Client;
using Microsoft.Extensions.Configuration;
using sit_booking_job.model;
using System.IO;
using System.Text;
using Microsoft.Office.Interop.Excel;  //第一步  添加excel第三方库
using Application = Microsoft.Office.Interop.Excel.Application; //声明excel
namespace sit_booking_job
{
    class Program
    {
      
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder().AddJsonFile($"appsettings.json", true, true);
            var config = builder.Build();

            Console.WriteLine(Environment.UserName);

            //updateUATdate(config);
            //return;

            string programName = config["AppSettings:Program"];
            switch (programName)
            {
                case "SyncInsertSeatUsageList":
                    SyncInsertSeatUsageList(config);
                    break;
                   


            }

        }
        public static void SyncInsertSeatUsageList(IConfigurationRoot config)
        {
            bool isDebug = config["AppSettings:Debug"] == "true";
            string functionName = "SyncInsertSeatUsageList";
            string logFileName = "SyncInsertSeatUsageListLog" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";
            string systemLogPath = config["AppSettings:LogPath"];
            // listUrl
            string PMATeamListUrl = config["AppSettings:PMATeamListUrl"];
            string LocationListUrl = config["AppSettings:LocationListUrl"];
            string ReservedListUrl = config["AppSettings:ReservedListUrl"];
            string SeatListUrl = config["AppSettings:SeatListUrl"];
            string SeatUsageListUrl = config["AppSettings:SeatUsageListUrl"];
            //SiteConfig
            string SitBookingSiteUrl = config["AppSettings:SitBookingSiteUrl"];
            string SitBookingClientId = config["AppSettings:SitBookingClientId"];
            string AKVName = config["AppSettings:AKVName"];
            string AKVAppSecret = config["AppSettings:AKVAppSecret"];
            string SitBookingClientSecret =
                isDebug
                    ? config["AppSettings:SitBookingClientSecret"]
                    : Helper.GetAKVSecret(AKVName, AKVAppSecret);
            // string now = DateTime.Now.ToString("yyyy-MM-dd");
            DateTime nowTest = new DateTime(2024,2,1);
            string now = nowTest.ToString("yyyy-MM-dd");
            ConcurrentQueue<SeatUsage> queue = new ConcurrentQueue<SeatUsage>();


            Helper.writeLogs("Start to " + functionName, systemLogPath + logFileName);
            ClientContext spContext = Helper.GetAppCtx(SitBookingSiteUrl, SitBookingClientId, SitBookingClientSecret);
            Web SitBookingWeb = spContext.Web;
            List ReservedList = SitBookingWeb.GetListByUrl(ReservedListUrl);
            List SeatList = SitBookingWeb.GetListByUrl(SeatListUrl);
            List SeatUsageList = SitBookingWeb.GetListByUrl(SeatUsageListUrl);

            CamlQuery SeatListQuery = new CamlQuery();
            SeatListQuery.ViewXml = @"<View>  
                                    </View>";
            // ListItemCollection SeatListItems = SeatList.GetItems(SeatListQuery);

            CamlQuery ReservedListQuery = new CamlQuery();
            ReservedListQuery.ViewXml = @"<View>  
                                    </View>";
            // ListItemCollection ReservedListItems = ReservedList.GetItems(ReservedListQuery);
            CamlQuery SeatUsageListQuery = new CamlQuery();
            SeatUsageListQuery.ViewXml = @"<View>  
                                    </View>";
             int rowLimit = 4000;
                string pagingInfo = null;
                string pagingInfo1 = null;
                List<ListItem> ReservedListItems = new List<ListItem>();
                // ADD TO TEST
                List<ListItem> SeatListItems = new List<ListItem>();
                 ListItemCollectionPosition Position = null;
                 ListItemCollectionPosition Position1 = null;

                 SeatListQuery.ViewXml = @"<View Scope='RecursiveAll'><RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
                Helper.writeLogs("Start to  get SeatList date in  sharepoint" + functionName, systemLogPath + logFileName);
                do
                {

                    ListItemCollection Page = null;
                    SeatListQuery.ListItemCollectionPosition = Position;
                    Page = SeatList.GetItems(SeatListQuery);
                    spContext
                    .Load(Page);

                    spContext.ExecuteQuery();

                    // pagingInfo=TCSRecordAllByPage.ListItemCollectionPosition?.PagingInfo;
                    Position = Page.ListItemCollectionPosition;
                    SeatListItems.AddRange(Page.ToList());
                } while (Position != null);

                ReservedListQuery.ViewXml = @"<View Scope='RecursiveAll'><RowLimit Paged='TRUE'>" + rowLimit + "</RowLimit></View>";
                Helper.writeLogs("Start to  get ReservedList date in  sharepoint" + functionName, systemLogPath + logFileName);
                do
                {

                    ListItemCollection Page = null;
                    ReservedListQuery.ListItemCollectionPosition = Position1;
                    Page = ReservedList.GetItems(ReservedListQuery);
                    spContext.Load(Page);

                    spContext.ExecuteQuery();

                    // pagingInfo=TCSRecordAllByPage.ListItemCollectionPosition?.PagingInfo;
                    Position1 = Page.ListItemCollectionPosition;
                    ReservedListItems.AddRange(Page.ToList());
                } while (Position1 != null);

            // ListItemCollection SeatUsageListItems = SeatUsageList.GetItems(SeatUsageListQuery);
            // spContext.Load(SeatListItems, items => items.Include(
            //     item => item.Id,
            //     items => items["City"],
            //     items => items["Building"],
            //     items => items["Floor"],
            //     items => items["Area"],
            //     items => items["Department"],
            //     items => items["SeatType"],
            //     items => items["SeatNo"]

            // ));


            // spContext.Load(ReservedListItems, items => items.Include(
            //     item => item.Id,
            //     items => items["Area"],
            //     items => items["SeatNo"],
            //     items => items["isAMBooked"],
            //     items => items["isPMBooked"],
            //     items => items["Day"]

            // ));
            // spContext.ExecuteQuery();

            List<SeatListItem> SeatListItemList = new List<SeatListItem>();
            List<ReservedListItem> ReservedListItemList = new List<ReservedListItem>();
            // try{

            // }catch{}


            try
            {
                foreach (ListItem item in SeatListItems)
                {

                    SeatListItem s = new SeatListItem();
                    s.City = item["City"] == null ? "" : item["City"].ToString();
                    s.Building = item["Building"] == null ? "" : item["Building"].ToString();
                    s.Floor = item["Floor"] == null ? "" : item["Floor"].ToString();
                    s.Area = item["Area"] == null ? "" : item["Area"].ToString();
                    s.Department = item["Department"] == null ? "" : item["Department"].ToString();
                    s.SeatType = item["SeatType"] == null ? "" : item["SeatType"].ToString();
                    s.SeatNo = item["SeatNo"] == null ? "" : item["SeatNo"].ToString();
                    SeatListItemList.Add(s);
                }
            }
            catch (Exception ex)
            {

                Helper.writeLogs("Error to loaded SeatList by " + ex.Message, systemLogPath + logFileName);
            }
            try
            {
                foreach (ListItem item in ReservedListItems)
                {

                    ReservedListItem r = new ReservedListItem();
                    r.Area = item["Area"] == null ? "" : item["Area"].ToString();
                    r.SeatNo = item["SeatNo"] == null ? "" : item["SeatNo"].ToString();
                    r.isAMBooked = item["isAMBooked"] == null ? "" : item["isAMBooked"].ToString();
                    r.isPMBooked = item["isPMBooked"] == null ? "" : item["isPMBooked"].ToString();
                    r.Day = item["Day"] == null ? "" : item["Day"].ToString();
                    r.UserDepartmentCode = item["UserDepartmentCode"] == null ? "" : item["UserDepartmentCode"].ToString();

                    ReservedListItemList.Add(r);
                }

            }
            catch (Exception ex)
            {
                Helper.writeLogs("Error to loaded ReservedList by" + ex.Message, systemLogPath + logFileName);
            }


            var sg = SeatListItemList.GroupBy(x => new { x.Department, x.City, x.Building, x.Floor, x.Area }).Select(group => new SeatListGroup
            {
                SBUCode = group.Key.Department,
                City = group.Key.City,
                Building = group.Key.Building,
                Floor = group.Key.Floor,
                Area = group.Key.Area,
                SeatLists = group.ToList()
            }).ToList();

            var rl = ReservedListItemList.GroupBy(x =>new{ x.Day,x.UserDepartmentCode} ).Select(group => new ReservedGroup
            {
                Day = group.Key.Day,
                UserDepartmentCode=group.Key.UserDepartmentCode,
                ReservedLists = group.ToList()
            });
            // Application app = new Application();
            // Workbook workbook = app.Workbooks.Add();
            // Worksheet worksheet = (Worksheet)workbook.Worksheets[1];

     
            // worksheet.Cells[1,1]="Day";
            // worksheet.Cells[1,2]="SBUCode";
            // worksheet.Cells[1,3]="City";
            // worksheet.Cells[1,4]="Building";
            // worksheet.Cells[1,5]="Floor";
            // worksheet.Cells[1,6]="Booked";
            // worksheet.Cells[1,7]="Fixed";
            // worksheet.Cells[1,8]="SeatCount";
            // worksheet.Cells[1,9]="YearMonthSBU";
            // worksheet.Cells[1,10]="YearMonthCityBuilding";

            // int row=2;
            string t="Day,SBUCode,City,Building,Floor,Booked,Fixed,SeatCount,YearMonthSBU,YearMonthCityBuilding";
            string excelFileName=DateTime.Now.ToString("yyyyMMddhhmmss")+"data.csv";
            FileStream fs = new FileStream(systemLogPath +excelFileName, FileMode.Create);
           StreamWriter sw = new StreamWriter(fs);
           StringBuilder sb = new StringBuilder();
           sw.WriteLine(t);
           sw.Flush();

            try
            {
                foreach (var g1 in sg)
                {
                    SeatUsage su = new SeatUsage();
                    su.City = g1.City;
                    su.SBUCode = g1.SBUCode;
                    su.Building = g1.Building;
                    su.Floor = g1.Floor;
                    su.Day = now;
                    su.SeatCount = g1.SeatLists.Count;
                    su.Booked = 0;
                    su.Fixed = g1.SeatLists.Where(p => p.SeatType == "3").ToList().Count;
                    su.YearMonthSBU = DateTime.Now.ToString("yyyy-MM") + "-" + g1.SBUCode;
                    su.YearMonthCityBuilding = DateTime.Now.ToString("yyyy-MM") + "-" + g1.City + "-" + g1.Building;

                    ReservedGroup today = rl.FirstOrDefault(x => x.Day == now &&x.UserDepartmentCode==su.SBUCode);
                    if(today!=null){
                    foreach (var item in today.ReservedLists)
                    {
                        if (item.Area == g1.Area)
                        {
                            if (item.isAMBooked == "True")
                            {
                                su.Booked = su.Booked + 0.5;

                            }
                           if (item.isPMBooked == "True")
                            {
                                su.Booked = su.Booked + 0.5;
                            }
                        }
                    }
                    }
                    string lineText=su.Day+","+su.SBUCode+","+su.City+","+su.Building+","+su.Floor+","+su.Booked+","+su.Fixed+","+su.SeatCount+","+su.YearMonthSBU+","+su.YearMonthCityBuilding;
            sw.WriteLine(lineText);
           sw.Flush();
        
            // worksheet.Cells[row,1]=su.Day;
            // worksheet.Cells[row,2]=su.SBUCode;
            // worksheet.Cells[row,3]=su.City;
            // worksheet.Cells[row,4]=su.Building;
            // worksheet.Cells[row,5]=su.Floor;
            // worksheet.Cells[row,6]=su.Booked;
            // worksheet.Cells[row,7]=su.Fixed;
            // worksheet.Cells[row,8]=su.SeatCount;
            // worksheet.Cells[row,9]=su.YearMonthSBU;
            // worksheet.Cells[row,10]=su.YearMonthCityBuilding;
            // row++;
         

                    // ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                    // ListItem newItem = SeatUsageList.AddItem(itemCreateInfo);

                    // newItem["Day"] = su.Day;
                    // newItem["SBUCode"] = su.SBUCode;
                    // newItem["City"] = su.City;
                    // newItem["Building"] = su.Building;
                    // newItem["Floor"] = su.Floor;
                    // newItem["Booked"] = su.Booked;
                    // newItem["Fixed"] = su.Fixed;
                    // newItem["SeatCount"] = su.SeatCount;
                    // newItem["YearMonthSBU"] = su.YearMonthSBU;
                    // newItem["YearMonthCityBuilding"] = su.YearMonthCityBuilding;
                    // // newItem["Title"] = su.Day;
                    // newItem.Update();



                    // spContext.ExecuteQuery();

                    //add to excel
         
                
                }
           sw.Close();
           fs.Close();
            // workbook.SaveAs(systemLogPath+now+".xlsx");
            // workbook.Close();
            // app.Quit();

            }
            catch (Exception ex)
            {
                Helper.writeLogs("Error to add SeatUsageList by " + ex.Message, systemLogPath + logFileName);
            }
            Helper.writeLogs("finish to add SeatUsageList! ", systemLogPath + logFileName);

        }


       
    }
}
