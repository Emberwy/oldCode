using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sit_booking_job.model
{
    public class ReservedGroup
    {
           public string Day{get;set;}
           public string UserDepartmentCode{get;set;}
            public List<ReservedListItem> ReservedLists{get;set;}
    }
}
