using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sit_booking_job.model
{
    public class ReservedListItem
    {
        public string Area {get;set;}
        public string SeatNo{get;set;}
        public string UserDepartmentCode{get;set;}
        // public string StartDate{get;set;}
        // public string EndDate{get;set;}
        public string isAMBooked{get;set;}
        public string isPMBooked{get;set;}
        public string Day{get;set;}

    }
}
