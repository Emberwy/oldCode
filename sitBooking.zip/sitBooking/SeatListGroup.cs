using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sit_booking_job.model
{
    public class SeatListGroup
    {
        public string SBUCode{get;set;}
        public string City{get;set;}  
        public string Building{get;set;}
        public string Floor{get;set;}
        public string Area{get;set;}

        public List<SeatListItem>SeatLists{get;set;}
    }
}
