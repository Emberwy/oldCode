using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sit_booking_job.model
{
    public class SeatListItem
    {
        public string City{get;set;}
        public string Building {get;set;}
        public string Floor{get;set;}
        public string Area{get;set;}
        public string Department{get;set;}
 
        // 3  fixed 
        public string SeatType{get;set;}
        public string SeatNo{get;set;}

    }
}
