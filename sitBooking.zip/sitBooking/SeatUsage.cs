using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sit_booking_job.model
{
    public class SeatUsage
    {
        public string Title {get;set;}
        public string Day{get;set;}
        public string SBUCode{get;set;}
        public string City{get;set;}
        public string Building{get;set;}
        public string Floor{get;set;}
        public double Booked{get;set;}
        public int Fixed{get;set;}
        public int SeatCount{get;set;}
        public string YearMonthSBU{get;set;}
        public string YearMonthCityBuilding{get;set;}
    }
}
